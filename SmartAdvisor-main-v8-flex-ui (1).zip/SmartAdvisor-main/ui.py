# -*- coding: utf-8 -*-
"""Web-интерфейс v7.8: проводник по описанию интеграции и справочник инвариантов.

Ядро анализа осталось прежним: UI собирает тот же JSON, что и v6.4+.
Дополнительно интерфейс показывает каталог архитектурных инвариантов как
понятный справочник: что проверить, почему это важно и пример ошибки.
"""
import os
from html import escape
from engine import SEVERITY_RU
from invariant_catalog import INVARIANT_CATALOG

APP_VERSION = '8.0-flex-ui'
BASE_PATH = os.environ.get('BASE_PATH', '').rstrip('/')

def url_for(path):
    if not path.startswith('/'):
        path = '/' + path
    return (BASE_PATH + path) or '/'

STATUS_RU = {'ok': 'Проверено', 'warn': 'Требует проверки', 'unknown': 'Не указано', 'fail': 'Блокирует выпуск',
             'pass': 'Проходит'}

CSS = """
:root{
  --paper:#F4F6F5; --panel:#FFFFFF; --ink:#15211F; --muted:#5C6B68;
  --line:#D7DEDC; --accent:#155E66; --accent-soft:#E3EEEF;
  --critical:#B3361C; --high:#B87714; --medium:#857C2E; --info:#5C6B68;
  --good:#1E6E3C;
  --mono:ui-monospace,'JetBrains Mono','Cascadia Mono',Menlo,Consolas,monospace;
  --sans:system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;
}
*{box-sizing:border-box}
body{margin:0;color:var(--ink);font:15px/1.55 var(--sans);background:var(--paper);
  background-image:linear-gradient(var(--line) 1px,transparent 1px),linear-gradient(90deg,var(--line) 1px,transparent 1px);
  background-size:28px 28px;}
.wrap{max-width:1120px;margin:0 auto;padding:20px 16px 72px}
.titleblock{display:flex;justify-content:space-between;align-items:flex-end;gap:12px;border:2px solid var(--ink);background:var(--panel);padding:14px 18px;margin-bottom:18px}
.titleblock h1{margin:0;font:700 19px/1.2 var(--mono);letter-spacing:.06em;text-transform:uppercase}
.titleblock .meta{font:11px/1.5 var(--mono);color:var(--muted);text-align:right;letter-spacing:.05em}
.hero{background:var(--panel);border:1px solid var(--line);border-left:6px solid var(--accent);padding:16px 18px;margin-bottom:18px}
.hero h2{margin:0 0 6px;font-size:20px}.hero p{margin:6px 0;color:var(--muted)}
.steps3{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:12px}.stepbox{border:1px solid var(--line);background:#FCFDFD;padding:10px 12px}.stepbox b{font-family:var(--mono);font-size:12px;color:var(--accent)}
.card{background:var(--panel);border:1px solid var(--line);border-top:3px solid var(--accent);padding:18px 20px;margin-bottom:18px}
.card h2{margin:0 0 12px;font:700 13px var(--mono);letter-spacing:.12em;text-transform:uppercase;color:var(--accent)}
details.card{padding:0}details.card>summary{display:flex;align-items:center;justify-content:space-between;gap:10px;cursor:pointer;padding:16px 20px;list-style:none}details.card>summary::-webkit-details-marker{display:none}details.card>summary h2{margin:0}details.card>summary:after{content:'развернуть';font:11px var(--mono);color:var(--muted)}details.card[open]>summary:after{content:'свернуть'}details.card>.inside{padding:0 20px 18px}
label{display:block;font:11px var(--mono);letter-spacing:.06em;color:var(--muted);margin:10px 0 3px;text-transform:uppercase}
input,select,textarea{width:100%;padding:8px 9px;border:1px solid var(--line);border-radius:0;font:14px var(--sans);background:#FCFDFD;color:var(--ink)}
textarea{font-family:var(--mono);font-size:13px;min-height:64px}input:focus,select:focus,textarea:focus{outline:2px solid var(--accent);outline-offset:-1px}
.grid{display:grid;gap:0 16px}.g2{grid-template-columns:repeat(2,1fr)}.g3{grid-template-columns:repeat(3,1fr)}.g4{grid-template-columns:repeat(4,1fr)}
.toolbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center}.toolbar .spacer{flex:1}.mode{display:inline-flex;border:1px solid var(--ink)}.mode button{border:0;border-right:1px solid var(--ink);background:#fff;color:var(--ink);padding:8px 12px;font:700 12px var(--mono);cursor:pointer}.mode button:last-child{border-right:0}.mode button.active{background:var(--ink);color:#fff}
.scenarios{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.scenario{border:1px solid var(--line);background:#FCFDFD;padding:12px;text-align:left;cursor:pointer;position:relative}.scenario:hover{border-color:var(--accent);background:var(--accent-soft)}.scenario.active{border-color:var(--accent);background:var(--accent-soft);box-shadow:inset 0 0 0 2px var(--accent)}.scenario.active:after{content:'Выбрано ✓';position:absolute;right:10px;top:8px;font:700 10px var(--mono);color:var(--accent)}.scenario b{display:block;margin-bottom:4px;padding-right:84px}.scenario span{font-size:12.5px;color:var(--muted)}.selected-scenario{margin:10px 0 0;font-weight:700;color:var(--accent)}.toast{position:fixed;right:18px;bottom:18px;z-index:10;max-width:360px;border:2px solid var(--accent);background:#fff;color:var(--ink);box-shadow:0 8px 22px rgba(0,0,0,.12);padding:12px 14px;font:700 12px var(--mono);opacity:0;transform:translateY(10px);transition:.18s ease}.toast.show{opacity:1;transform:translateY(0)}
table{width:100%;border-collapse:collapse;font-size:13px}th{font:10px var(--mono);letter-spacing:.08em;text-transform:uppercase;color:var(--muted);text-align:left;padding:6px 6px;border-bottom:2px solid var(--ink)}td{padding:5px 4px;border-bottom:1px solid var(--line);vertical-align:top}td input,td select{padding:6px 6px;font-size:13px}
.btn{display:inline-block;border:2px solid var(--ink);background:var(--ink);color:#fff;font:700 13px var(--mono);letter-spacing:.08em;text-transform:uppercase;padding:11px 22px;cursor:pointer;text-decoration:none}.btn:hover{background:var(--accent);border-color:var(--accent)}.btn.ghost{background:transparent;color:var(--ink);font-weight:600;padding:7px 12px;border-width:1px}.btn.ghost:hover{color:var(--accent);border-color:var(--accent);background:var(--accent-soft)}.btn:focus-visible{outline:3px solid var(--accent);outline-offset:2px}
.progress{height:10px;background:#E7ECEB;border:1px solid var(--line);margin:8px 0 4px}.progress i{display:block;height:100%;width:0;background:var(--accent)}
.rail{display:flex;flex-wrap:wrap;align-items:center;gap:0;padding:14px 6px;min-height:58px}.rail .chip{border:1.5px solid var(--ink);background:var(--panel);padding:6px 10px;font:12px var(--mono);max-width:240px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.rail .chip small{display:block;color:var(--muted);font-size:10px;letter-spacing:.05em}.rail .link{width:34px;border-top:2px solid var(--ink);position:relative;flex:none}.rail .link.async{border-top-style:dashed;border-top-color:var(--muted)}.rail .link::after{content:'';position:absolute;right:-1px;top:-4px;border:3px solid transparent;border-left:6px solid var(--ink)}.rail .link.async::after{border-left-color:var(--muted)}.rail:empty::before{content:'Шаги появятся здесь по мере добавления';color:var(--muted);font:12px var(--mono)}
.hint{font-size:12.5px;color:var(--muted);margin:4px 0 0}.err{border:2px solid var(--critical);color:var(--critical);background:#FBEEE9;padding:10px 14px;margin:10px 0;font:13px var(--mono)}a{color:var(--accent)}
.quick-mode .advanced-only{display:none!important}.quick-note{display:none}.quick-mode .quick-note{display:block}.advanced-note{display:block}.quick-mode .advanced-note{display:none}
.badge{font:10px var(--mono);letter-spacing:.05em;padding:1px 6px;border:1px solid currentColor}.b-critical{color:var(--critical)}.b-high{color:var(--high)}.b-medium{color:var(--medium)}.b-info{color:var(--info)}
.verdict{border:2px solid var(--ink);padding:16px 20px;margin-bottom:18px;background:var(--panel)}.verdict.green{border-color:var(--good);box-shadow:inset 6px 0 0 var(--good)}.verdict.yellow{border-color:var(--high);box-shadow:inset 6px 0 0 var(--high)}.verdict.red{border-color:var(--critical);box-shadow:inset 6px 0 0 var(--critical)}.verdict h2{margin:0;font:700 16px var(--mono);letter-spacing:.04em}.verdict p{margin:6px 0 0;color:var(--muted);font:12px var(--mono)}
.finding{border:1px solid var(--line);border-left:4px solid var(--info);padding:12px 14px;margin:0 0 10px;background:#FCFDFD}.finding.critical{border-left-color:var(--critical)}.finding.high{border-left-color:var(--high)}.finding.medium{border-left-color:var(--medium)}.finding h3{margin:0 0 2px;font-size:14.5px}.finding .where{font:11px var(--mono);color:var(--muted)}.finding p{margin:7px 0 0;font-size:13.5px}
pre{background:#10201E;color:#D9E6E3;padding:14px;overflow:auto;font:12.5px var(--mono);margin:8px 0}.mermaid{background:#FCFDFD;border:1px solid var(--line);padding:8px;margin:8px 0;overflow:auto}ol.tests{padding-left:20px;font-size:13.5px}ol.tests li{margin:5px 0}.pat{margin:0 0 12px}.pat b{font-family:var(--mono)}.pat .ctl{font:12px var(--mono);color:var(--muted)}
.gates{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.gate{border:1px solid var(--line);padding:10px 12px;background:#FCFDFD}.gate.fail{border-left:4px solid var(--critical)}.gate.warn{border-left:4px solid var(--high)}.gate.pass{border-left:4px solid var(--good)}.gate b{font-family:var(--mono);font-size:12px}.gate p{margin:6px 0 0;font-size:12.5px;color:var(--muted)}
.check{width:100%;border-collapse:collapse}.check td,.check th{font-size:12.5px;padding:7px;border-bottom:1px solid var(--line)}.st{font:10px var(--mono);letter-spacing:.05em;padding:2px 6px;border:1px solid currentColor;white-space:nowrap}.st.ok,.st.pass{color:var(--good)}.st.warn,.st.unknown{color:var(--high)}.st.fail{color:var(--critical)}
.alt{border:1px solid var(--line);padding:12px 14px;margin:0 0 10px;background:#FCFDFD}.alt h3{margin:0;font-size:14px}.alt p{margin:6px 0;font-size:13px}.alt ul{margin:6px 0 0 18px;padding:0;font-size:13px}.two{display:grid;grid-template-columns:1fr 1fr;gap:12px}.actions{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.action{border:1px solid var(--line);background:#FCFDFD;padding:10px 12px}.action b{font-family:var(--mono);font-size:12px}.flowbox{border:1px solid var(--line);background:#FCFDFD;padding:10px 12px;margin:0 0 10px}.flowbox h3{margin:0 0 5px;font-size:14px}.flowbox ul{margin:6px 0 0 18px;padding:0}.flowbox li{margin:3px 0}.flowbox .meta{font:11px var(--mono);color:var(--muted)}

.navlinks{display:flex;gap:10px;flex-wrap:wrap;margin-top:12px}
.navlinks a{display:inline-block;border:1px solid var(--ink);padding:8px 10px;background:#fff;color:var(--ink);text-decoration:none;font:12px var(--mono);text-transform:uppercase;letter-spacing:.05em}.topnav{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}.topnav a{border:1px solid var(--line);background:#fff;color:var(--ink);padding:7px 10px;font:700 11px var(--mono);text-transform:uppercase;letter-spacing:.04em;text-decoration:none}.topnav a.primary{background:var(--accent);border-color:var(--accent);color:#fff}.invariant-entry{border-top-color:var(--good);background:#FCFDFD}
.refbar{display:grid;grid-template-columns:1fr 260px;gap:12px;margin:12px 0}
.refcard{border:1px solid var(--line);background:#fff;padding:14px;margin:10px 0}
.refcard h3{margin:0 0 8px;font:700 17px/1.3 var(--sans)}
.refcode{display:inline-block;font:11px var(--mono);border:1px solid var(--line);padding:2px 6px;margin-right:8px;background:#F4F6F7;color:var(--muted)}
.refarea{font:11px var(--mono);text-transform:uppercase;letter-spacing:.06em;color:var(--muted)}
.refgrid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px}
.refbox{background:#F8FAFA;border:1px solid var(--line);padding:10px}
.refbox b{display:block;margin-bottom:5px}
.reflead{border-left:4px solid var(--accent);background:#F6FBFA;margin:10px 0}.okbox{border-left:4px solid var(--good);background:#F7FBF8;margin-top:10px}
.refexample{border-left:4px solid var(--ink);background:#FBFCFC;padding:10px;margin-top:10px}.refexample.light{border-left-color:var(--high);background:#FFFDF8}.dangerbox{border-left:4px solid var(--critical);background:#FFF7F7;margin-top:10px}
.refempty{display:none;border:1px dashed var(--line);padding:16px;background:#fff}
@media(max-width:760px){.refbar,.refgrid{grid-template-columns:1fr}.navlinks a{width:100%}}

@media(max-width:860px){.g3,.g4,.scenarios,.steps3,.actions,.minimal{grid-template-columns:1fr 1fr}.wrap{padding:12px 8px}.card{padding:14px 12px}.titleblock{display:block}.titleblock .meta{text-align:left;margin-top:8px}}
.help{border-left:3px solid var(--accent);background:#F7FAFA;padding:8px 10px;margin:6px 0 10px;font-size:12.5px;color:var(--muted)}
.help b{color:var(--ink)}
.fieldtip{font-size:12px;color:var(--muted);margin:3px 0 0}
#steps{border-collapse:separate;border-spacing:0 10px}
#steps thead{display:none}
#steps tbody tr{display:grid;grid-template-columns:52px minmax(220px,1.7fr) minmax(150px,1fr) 128px 120px 82px minmax(110px,.8fr) minmax(135px,.9fr) 120px 80px minmax(220px,1.4fr) 42px;gap:8px;align-items:end;border:1px solid var(--line);background:#FCFDFD;padding:10px;margin-bottom:10px}
#steps td{border:0;padding:0}
#steps td:before{content:attr(data-label);display:block;font:10px var(--mono);letter-spacing:.06em;text-transform:uppercase;color:var(--muted);margin-bottom:3px}
.resultnav{position:sticky;top:0;z-index:3;background:rgba(244,246,245,.96);backdrop-filter:blur(4px);border:1px solid var(--line);padding:8px;margin:0 0 14px;display:flex;gap:6px;flex-wrap:wrap}
.resultnav a{border:1px solid var(--line);background:#fff;color:var(--ink);padding:8px 10px;font:700 11px var(--mono);text-transform:uppercase;letter-spacing:.04em;text-decoration:none}.resultnav a:hover{background:var(--accent-soft);border-color:var(--accent);color:var(--accent)}.resultnav a.active,.guidebar a.active{background:var(--accent);border-color:var(--accent);color:#fff}
.jumpfix{display:inline-block;margin-top:8px;border:1px solid var(--line);padding:5px 8px;background:#fff;font:11px var(--mono);text-decoration:none;color:var(--accent)}
.top10{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.top10 .refbox{background:#FCFDFD}
.guidebar{position:sticky;top:0;z-index:4;background:rgba(244,246,245,.97);backdrop-filter:blur(4px);border:1px solid var(--line);padding:8px;margin:0 0 14px;display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.guidebar a{border:1px solid var(--line);background:#fff;color:var(--ink);padding:8px 10px;font:700 11px var(--mono);text-transform:uppercase;letter-spacing:.04em;text-decoration:none}.guidebar a:hover{background:var(--accent-soft);border-color:var(--accent);color:var(--accent)}
.guidebar .guide-title{font:700 11px var(--mono);color:var(--muted);margin-right:4px;text-transform:uppercase;letter-spacing:.06em}
.assist{border:1px solid var(--line);background:#FBFDFD;padding:12px 14px;margin-top:10px}.assist b{font-family:var(--mono);font-size:12px;color:var(--accent)}
.assist ul{margin:8px 0 0 18px;padding:0}.assist li{margin:3px 0}.assist.ok{border-left:4px solid var(--good)}.assist.warn{border-left:4px solid var(--high)}
.templatebar{display:flex;flex-wrap:wrap;gap:8px;margin:10px 0 12px}.templatebar .btn{letter-spacing:.03em;text-transform:none;font-size:12px;padding:8px 10px}
.process-layout{display:grid;grid-template-columns:minmax(0,1fr) 310px;gap:14px;align-items:start}.sidepanel{position:sticky;top:62px;border:1px solid var(--line);background:#FCFDFD;padding:12px}.sidepanel h3{margin:0 0 8px;font:700 12px var(--mono);text-transform:uppercase;letter-spacing:.08em;color:var(--accent)}.sidepanel p{margin:6px 0;color:var(--muted);font-size:12.5px}.sidepanel ul{margin:8px 0 0 18px;padding:0;font-size:12.5px}.sidepanel li{margin:4px 0}
.row-actions{display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end}.row-actions button{border:1px solid var(--line);background:#fff;color:var(--ink);padding:5px 7px;font:700 11px var(--mono);cursor:pointer}.row-actions button:hover{border-color:var(--accent);color:var(--accent);background:var(--accent-soft)}
.reviewbox{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.reviewbox .metric{border:1px solid var(--line);background:#FCFDFD;padding:10px}.reviewbox .metric b{display:block;font:700 18px var(--mono);color:var(--accent)}.reviewbox .metric span{font-size:12px;color:var(--muted)}
.minimal{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:10px}.minimal .mini{border:1px solid var(--line);background:#fff;padding:8px 10px}.minimal .mini b{display:block;font:700 11px var(--mono);color:var(--accent);margin-bottom:3px}.minimal .mini span{font-size:12px;color:var(--muted)}
#scenario,#basics,#systems-block,#process-designer,#review,#main-actions,#checklist,#scenario-base,#artifacts{scroll-margin-top:92px}
@media(max-width:900px){#steps tbody tr{grid-template-columns:1fr 1fr}.resultnav,.guidebar{position:static}.top10,.process-layout,.reviewbox,.minimal{grid-template-columns:1fr}.sidepanel{position:static}}

@media(max-width:640px){.guidebar a{width:100%}.process-layout,.reviewbox,.minimal{grid-template-columns:1fr}#steps tbody tr{display:block}#steps td{display:grid;grid-template-columns:128px 1fr;gap:8px;align-items:center;padding:5px 0}.g2,.g3,.g4,.gates,.two,.scenarios,.steps3,.actions{grid-template-columns:1fr}.toolbar{display:block}.toolbar>*{margin:6px 0}.mode{display:flex}.mode button{flex:1}.card{padding:12px}.titleblock h1{font-size:16px}table,thead,tbody,tr,td,th{display:block;width:100%}thead{display:none}tr{border:1px solid var(--line);background:#FCFDFD;margin:10px 0;padding:8px}td{border:0;display:grid;grid-template-columns:128px 1fr;gap:8px;align-items:center;padding:5px 0}td:before{content:attr(data-label);font:10px var(--mono);letter-spacing:.06em;text-transform:uppercase;color:var(--muted)}td:last-child{display:block;text-align:right}.check{display:table}.check thead{display:table-header-group}.check tbody{display:table-row-group}.check tr{display:table-row;border:0;background:transparent;margin:0;padding:0}.check td,.check th{display:table-cell}.check td:before{content:none}}


/* v8.0 flexible process builder overrides */
body{background:#F5F7F7;background-image:none;overflow-x:hidden}.wrap{max-width:1280px}.titleblock{border:1px solid var(--line);border-radius:18px;box-shadow:0 8px 28px rgba(15,23,42,.06);align-items:center}.titleblock h1{font-family:var(--sans);text-transform:none;letter-spacing:0;font-size:22px}.titleblock .meta{font-family:var(--sans);letter-spacing:0}.topnav{margin-top:10px}.topnav a{display:inline-flex;margin-right:8px;padding:7px 10px;border-radius:999px;text-decoration:none;color:var(--ink);background:#F8FAFA;border:1px solid var(--line)}.topnav a.primary{background:var(--accent);border-color:var(--accent);color:white}.hero,.card{border:1px solid var(--line);border-radius:18px;box-shadow:0 8px 28px rgba(15,23,42,.05);border-top:0}.hero{border-left:0;border-radius:18px}.card h2{font-family:var(--sans);font-size:18px;letter-spacing:0;text-transform:none;color:var(--ink)}label{font-family:var(--sans);text-transform:none;letter-spacing:0;font-weight:700;font-size:13px;color:#374151}input,select,textarea{border-radius:12px;padding:10px 11px;border-color:#DDE5E3;background:#fff}.btn{border-radius:12px;font-family:var(--sans);letter-spacing:0;text-transform:none}.btn.ghost{border-radius:12px}.guidebar{position:sticky;top:0;z-index:5;display:flex;gap:8px;flex-wrap:wrap;align-items:center;background:rgba(245,247,247,.94);backdrop-filter:blur(10px);padding:8px 0 12px}.guidebar a,.guide-title{font-size:13px}.guidebar a{border:1px solid var(--line);border-radius:999px;padding:7px 10px;background:#fff;text-decoration:none}.minimal{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin:10px 0}.mini,.metric,.assist,.help{border:1px solid var(--line);border-radius:14px;background:#FAFCFC;padding:10px 12px;min-width:0;overflow-wrap:anywhere}.mini b,.metric b{display:block}.mini span,.metric span{font-size:12px;color:var(--muted)}.assist{margin-top:10px}.assist.ok{border-left:5px solid var(--good)}.assist.warn{border-left:5px solid var(--high)}.navlinks{display:flex;gap:10px;flex-wrap:wrap;margin-top:12px}.fieldtip{font-size:12px;color:var(--muted);margin-top:4px}.templatebar{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0}.invariant-entry{display:none}
.builder-layout{display:grid;grid-template-columns:240px minmax(0,1fr)320px;gap:16px;align-items:start}.component-palette,.chain-workspace,.chain-preview{min-width:0}.component-palette,.chain-preview{position:sticky;top:72px}.palette-grid{display:grid;gap:8px}.palette-btn{width:100%;white-space:normal;text-align:left;border:1px solid var(--line);background:#fff;border-radius:12px;padding:10px;cursor:pointer}.palette-btn b{display:block}.palette-btn small{display:block;color:var(--muted);line-height:1.35}.systems-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin:10px 0 16px}.system-card,.chain-component,.map-node,.readiness-item{border:1px solid var(--line);border-radius:16px;background:#fff;padding:13px;min-width:0;overflow-wrap:anywhere;box-shadow:0 4px 14px rgba(15,23,42,.04)}.system-card .card-top,.component-header{display:flex;gap:8px;align-items:center;justify-content:space-between;flex-wrap:wrap}.system-card strong{font-size:15px}.chain-list{display:grid;gap:12px}.chain-component{position:relative}.chain-component.dragging{opacity:.55}.chain-component.drop-target{outline:2px dashed var(--accent);outline-offset:4px}.component-header{margin-bottom:10px}.component-title{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.step-number{font-weight:800}.channel-chip{display:inline-flex;border-radius:999px;padding:4px 8px;font-size:12px;background:var(--accent-soft);color:var(--accent);font-weight:700}.component-actions{display:flex;flex-wrap:wrap;gap:6px}.iconbtn{border:1px solid var(--line);border-radius:10px;background:#fff;min-width:34px;padding:7px 9px;cursor:pointer}.iconbtn:hover,.palette-btn:hover{border-color:var(--accent);background:var(--accent-soft)}.component-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.chip-select{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}.chip-option{border:1px solid var(--line);border-radius:999px;padding:7px 10px;background:#fff;cursor:pointer}.chip-option.active{border-color:var(--accent);background:var(--accent-soft);color:var(--accent);font-weight:700}.details-panel{margin-top:10px}.details-panel summary{cursor:pointer;color:var(--accent);font-weight:700}.process-map{display:grid;gap:10px}.map-node small,.map-node span{display:block;overflow-wrap:anywhere}.map-arrow{font-size:18px;color:var(--muted);text-align:center}.readiness-list{display:grid;gap:8px}.readiness-item{display:flex;justify-content:space-between;gap:8px;align-items:center}.readiness-item b{font-size:13px}.status-dot{border-radius:999px;padding:3px 7px;font-size:12px;font-weight:700}.status-dot.ok{background:#ECFDF3;color:var(--good)}.status-dot.warn{background:#FFF7ED;color:#9A3412}.status-dot.fail{background:#FEF2F2;color:#991B1B}.builder-empty{border:1px dashed var(--line);border-radius:16px;background:#FAFCFC;padding:18px;color:var(--muted);text-align:center}.sticky-submit{position:sticky;bottom:10px;z-index:4;background:rgba(245,247,247,.92);backdrop-filter:blur(10px);border:1px solid var(--line);border-radius:16px;padding:10px;display:flex;gap:10px;justify-content:space-between;align-items:center;flex-wrap:wrap}.legacy-store{display:none!important}
.refbar{display:grid;grid-template-columns:minmax(0,1fr)260px;gap:12px}.top10{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:10px}.ref-list{display:grid;gap:12px}.refcard{border:1px solid var(--line);border-radius:16px;background:#fff;overflow:hidden;min-width:0;overflow-wrap:anywhere}.refcard[open]{box-shadow:0 8px 24px rgba(15,23,42,.08)}.ref-summary{cursor:pointer;padding:14px 16px;list-style:none}.ref-summary::-webkit-details-marker{display:none}.ref-summary-top{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:8px}.ref-summary h3{margin:0 0 6px;font-size:16px;line-height:1.3;overflow-wrap:anywhere}.ref-summary p{margin:0;color:var(--muted);line-height:1.45;overflow-wrap:anywhere}.ref-content{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;padding:0 16px 16px}.ref-section{border:1px solid var(--line);border-radius:12px;background:#FCFDFD;padding:12px;min-width:0;overflow-wrap:anywhere}.ref-section h4{margin:0 0 6px;font-size:13px;line-height:1.3}.ref-section p,.ref-section li{margin:0;line-height:1.5;overflow-wrap:anywhere}.ref-section ul{margin:6px 0 0 18px;padding:0}.ref-section.ok{border-left:4px solid var(--good)}.ref-section.danger{border-left:4px solid var(--critical)}.ref-section.example{border-left:4px solid var(--accent)}.refcode,.refarea{display:inline-flex;max-width:100%;border-radius:999px;padding:4px 8px;font-size:11px;line-height:1.2;overflow-wrap:anywhere}.refcode{background:var(--accent-soft);color:var(--accent);font-weight:700}.refarea{background:#F1F5F9;color:var(--muted)}.refempty{display:none;border:1px dashed var(--line);border-radius:14px;padding:14px;background:#fff;color:var(--muted)}
@media(max-width:1100px){.builder-layout{grid-template-columns:1fr}.component-palette,.chain-preview{position:static}.steps3,.minimal,.g4,.g3{grid-template-columns:1fr 1fr}.guidebar{position:static}}@media(max-width:760px){.refbar,.ref-content{grid-template-columns:1fr}.ref-summary{padding:12px}.ref-content{padding:0 12px 12px}}@media(max-width:640px){.wrap{padding:10px 10px 86px}.titleblock{align-items:flex-start;flex-direction:column}.steps3,.minimal,.g2,.g3,.g4,.component-grid{grid-template-columns:1fr}.component-actions button,.builder-actions button,.palette-btn,.sticky-submit .btn{width:100%}.systems-grid{grid-template-columns:1fr}.chain-component,.system-card,.card,.hero{padding:12px}.sticky-submit{left:8px;right:8px}.process-map{overflow-x:visible}table:not(.check){display:none!important}}
"""

FORM_JS = r"""
const CH=[['rest','REST'],['grpc','gRPC'],['soap','SOAP'],['db','БД'],['kafka','Kafka'],['queue','Очередь'],['webhook','Webhook'],['callback','Callback'],['file','Файл'],['batch','Batch'],['cdc','CDC']];
const ROLES=[['internal','Внутренний сервис'],['external','Внешняя система'],['broker','Брокер сообщений'],['db','База данных'],['legacy','Legacy-система'],['analytics','DWH / аналитика']];
const CRIT=[['low','Низкая'],['medium','Средняя'],['high','Высокая'],['critical','Критичная']];
const STAB=[['unknown','Не указано'],['stable','Стабильная'],['unstable','Нестабильная'],['limited','Есть лимиты']];
const RETRY=[['none','Не повторяем'],['auto','Автоматически'],['manual','Вручную']];
const IDEM=[['none','Не указана'],['key','По idempotency key'],['natural','По бизнес-ключу']];
const SYNC=new Set(['rest','grpc','soap','db']);
const ASYNC=new Set(['kafka','queue','webhook','callback','file','batch','cdc']);
const BASE_PATH=(document.documentElement.dataset.basePath||'').replace(/\/$/,'');
const state={mode:'quick',systems:[],steps:[]};
let dragStepId=null;
function appUrl(path){if(!path.startsWith('/')) path='/'+path; return (BASE_PATH+path)||'/'}
function uid(prefix){return prefix+'_'+Math.random().toString(36).slice(2,9)}
function esc(s){const d=document.createElement('i');d.textContent=s||'';return d.innerHTML}
function v(id){return document.getElementById(id)?.value||''}
function setv(id,val){const el=document.getElementById(id); if(el) el.value=val||''}
function labelOf(list,val){const x=list.find(i=>i[0]===val);return x?x[1]:val}
function optPairs(list,sel){return list.map(x=>`<option value="${x[0]}" ${x[0]===sel?'selected':''}>${x[1]}</option>`).join('')}
function roleLabel(v){return labelOf(ROLES,v||'internal')}
function normalizeBool(v){return v==='yes'||v===true||v==='true'}
function ensureSystem(name, role='internal'){
  name=(name||'').trim(); if(!name) return;
  if(!state.systems.some(s=>s.name===name)) addSystem({name,role,owner:'',criticality:'medium',stability:'unknown'}, false);
}
function addSystem(data={}, rerender=true){
  state.systems.push({id:data.id||uid('sys'),name:data.name||'',role:data.role||'internal',owner:data.owner||'',criticality:data.criticality||data.crit||'medium',stability:data.stability||data.stab||'unknown',rate_limit_rps:data.rate_limit_rps||data.limit||''});
  if(rerender) renderAll();
}
function deleteSystem(id){
  const sys=state.systems.find(s=>s.id===id); if(!sys) return;
  state.systems=state.systems.filter(s=>s.id!==id);
  showToast('Система удалена. Шаги, где она была указана, подсвечены в проверке готовности.');
  renderAll();
}
function updateSystem(id,key,val){const s=state.systems.find(x=>x.id===id); if(!s)return; s[key]=val; renderSysList(); syncLegacyTables(); renderProcessMap(); renderReadiness();}
function presetSystem(kind){
  const map={internal:{name:'Новый сервис',role:'internal'},external:{name:'Внешняя система',role:'external'},broker:{name:'Kafka',role:'broker'},db:{name:'БД процесса',role:'db'},analytics:{name:'DWH',role:'analytics'},legacy:{name:'Legacy-система',role:'legacy'}};
  addSystem(map[kind]||{});
}
function safeDefaultsFor(channel){
  if(['rest','grpc','soap'].includes(channel)) return {blocking:'yes',timeout_ms:'500',retry:'auto',idempotency:'key',failure_policy:'Повторить автоматически',compensation:'timeout, circuit breaker, fallback, ограниченный retry с backoff'};
  if(['kafka','queue'].includes(channel)) return {blocking:'no',timeout_ms:'',retry:'auto',idempotency:'key',failure_policy:'DLQ / replay',compensation:'retry с backoff, DLQ, replay, контроль offset/ack'};
  if(['webhook','callback'].includes(channel)) return {blocking:'no',timeout_ms:'',retry:'auto',idempotency:'key',failure_policy:'DLQ / ручной разбор',compensation:'подпись, timestamp/nonce, Inbox-дедупликация, повтор callback'};
  if(channel==='db') return {blocking:'yes',timeout_ms:'200',retry:'none',idempotency:'natural',failure_policy:'Откатить / компенсировать',compensation:'транзакция, UNIQUE constraint, optimistic locking'};
  if(['file','batch'].includes(channel)) return {blocking:'no',timeout_ms:'',retry:'manual',idempotency:'natural',failure_policy:'Ручной разбор',compensation:'batchId, checksum, quarantine, reprocess'};
  if(channel==='cdc') return {blocking:'no',timeout_ms:'',retry:'auto',idempotency:'natural',failure_policy:'Replay / resync',compensation:'offset/LSN, watermark, replay/resync'};
  return {blocking:'yes',timeout_ms:'',retry:'none',idempotency:'none',failure_policy:'Пока не знаю',compensation:''};
}
function presetStep(kind){
  const presets={
    rest:{name:'Вызвать API',channel:'rest',component_type:'action'},
    kafka:{name:'Опубликовать или обработать событие',channel:'kafka',system:'Kafka',target_system:'Потребитель',component_type:'event'},
    db:{name:'Записать или обновить состояние в БД',channel:'db',target_system:'БД процесса',writes_entity:'yes',component_type:'storage'},
    webhook:{name:'Принять webhook или callback',channel:'webhook',component_type:'callback'},
    batch:{name:'Передать или обработать пакет данных',channel:'batch',component_type:'batch'},
    cdc:{name:'Передать изменения через CDC',channel:'cdc',component_type:'cdc'},
    manual:{name:'Ручная проверка или решение оператора',channel:'rest',blocking:'no',retry:'manual',idempotency:'natural',failure_policy:'Ручной разбор',compensation:'ручной разбор по runbook',component_type:'manual'},
    validation:{name:'Проверить данные и бизнес-правила',channel:'rest',blocking:'yes',timeout_ms:'300',retry:'none',idempotency:'natural',failure_policy:'Остановить процесс с понятной ошибкой',compensation:'валидационная ошибка без изменения состояния',component_type:'validation'}
  };
  const p={...(presets[kind]||{})};
  const d=safeDefaultsFor(p.channel||'rest');
  return {...d,...p,writes_entity:p.writes_entity||'no'};
}
function addStep(data={}, insertIndex=null, rerender=true){
  const channel=data.channel||'rest'; const d=safeDefaultsFor(channel);
  const step={id:data.id||uid('step'),order:1,name:data.name||'',source_system:data.source_system||'',system:data.system||'',target_system:data.target_system||'',channel,blocking:data.blocking||d.blocking,timeout_ms:data.timeout_ms==null?d.timeout_ms:String(data.timeout_ms||''),retry:data.retry||d.retry,idempotency:data.idempotency||d.idempotency,writes_entity:data.writes_entity||'no',depends_on:data.depends_on?String(data.depends_on):'',compensation:data.compensation||d.compensation,failure_policy:data.failure_policy||d.failure_policy,component_type:data.component_type||'action'};
  if(insertIndex===null || insertIndex<0 || insertIndex>state.steps.length) state.steps.push(step); else state.steps.splice(insertIndex,0,step);
  if(step.system) ensureSystem(step.system, step.channel==='kafka'||step.channel==='queue'?'broker':'internal');
  if(step.target_system && step.channel==='db') ensureSystem(step.target_system,'db');
  if(step.channel==='kafka') ensureSystem('Kafka','broker');
  if(step.channel==='db') ensureSystem(step.target_system||'БД процесса','db');
  renumberSteps(); if(rerender) renderAll();
}
function deleteStep(id){state.steps=state.steps.filter(s=>s.id!==id); renumberSteps(); renderAll();}
function duplicateStep(id){const i=state.steps.findIndex(s=>s.id===id); if(i<0)return; const c={...state.steps[i],id:uid('step'),name:(state.steps[i].name||'Шаг')+' — копия'}; state.steps.splice(i+1,0,c); renumberSteps(); renderAll();}
function moveStep(id,dir){const i=state.steps.findIndex(s=>s.id===id); if(i<0)return; const ni=i+dir; if(ni<0||ni>=state.steps.length)return; const [x]=state.steps.splice(i,1); state.steps.splice(ni,0,x); renumberSteps(); renderAll();}
function insertStepAfter(id,kind='rest'){const i=state.steps.findIndex(s=>s.id===id); addStep(presetStep(kind),i+1);}
function insertStepBefore(id,kind='rest'){const i=state.steps.findIndex(s=>s.id===id); addStep(presetStep(kind),i<0?0:i);}
function renumberSteps(){state.steps.forEach((s,i)=>{s.order=i+1; if(i>0 && !s.depends_on) s.depends_on=String(i);});}
function applySafeDefaultsToStep(id){const s=state.steps.find(x=>x.id===id); if(!s)return; const d=safeDefaultsFor(s.channel); Object.assign(s,{blocking:d.blocking,timeout_ms:s.timeout_ms||d.timeout_ms,retry:d.retry,idempotency:d.idempotency,compensation:s.compensation||d.compensation,failure_policy:d.failure_policy}); renderAll();}
function applySafeDefaultsAll(){state.steps.forEach(s=>{const d=safeDefaultsFor(s.channel); Object.assign(s,{blocking:d.blocking,timeout_ms:s.timeout_ms||d.timeout_ms,retry:d.retry,idempotency:d.idempotency,compensation:s.compensation||d.compensation,failure_policy:s.failure_policy||d.failure_policy});}); renderAll();}
function updateStep(id,key,val){const s=state.steps.find(x=>x.id===id); if(!s)return; s[key]=val; if(['source_system','system','target_system'].includes(key)) ensureSystem(val); if(key==='channel'){const d=safeDefaultsFor(val); s.blocking=d.blocking; s.retry=d.retry; s.idempotency=d.idempotency; if(!s.timeout_ms) s.timeout_ms=d.timeout_ms; if(!s.compensation) s.compensation=d.compensation; s.failure_policy=d.failure_policy; if(val==='kafka')ensureSystem('Kafka','broker'); if(val==='db')ensureSystem(s.target_system||'БД процесса','db');} renderAll();}
function renderSysList(){const dl=document.getElementById('syslist'); if(dl) dl.innerHTML=state.systems.map(s=>`<option value="${esc(s.name)}">`).join('');}
function renderSystems(){
  const box=document.getElementById('systemsCards'); if(!box)return; renderSysList();
  box.innerHTML=state.systems.length?state.systems.map(s=>`<article class="system-card" data-id="${s.id}"><div class="card-top"><strong>${esc(s.name||'Новая система')}</strong><button type="button" class="iconbtn" data-action="delete-system" data-id="${s.id}" aria-label="Удалить систему">×</button></div><label>Название системы</label><input value="${esc(s.name)}" data-system-field="name" data-id="${s.id}" placeholder="Например: Банк"><label>Роль</label><select data-system-field="role" data-id="${s.id}">${optPairs(ROLES,s.role)}</select><label>Владелец</label><input value="${esc(s.owner)}" data-system-field="owner" data-id="${s.id}" placeholder="Команда или организация"><div class="advanced-only"><label>Критичность</label><select data-system-field="criticality" data-id="${s.id}">${optPairs(CRIT,s.criticality)}</select><label>Стабильность / лимиты</label><select data-system-field="stability" data-id="${s.id}">${optPairs(STAB,s.stability)}</select><label>RPS-лимит</label><input value="${esc(s.rate_limit_rps)}" data-system-field="rate_limit_rps" data-id="${s.id}" inputmode="numeric" placeholder="100"></div></article>`).join(''):'<div class="builder-empty">Пока нет участников. Добавьте систему из палитры или выберите готовый сценарий.</div>';
  syncLegacyTables();
}
function channelChips(step){return CH.filter(x=>['rest','grpc','soap','db','kafka','queue','webhook','callback','file','batch','cdc'].includes(x[0])).map(([val,label])=>`<button type="button" class="chip-option ${step.channel===val?'active':''}" data-action="set-channel" data-id="${step.id}" data-channel="${val}">${label}</button>`).join('')}
function renderSteps(){
  const box=document.getElementById('chainList'); if(!box)return;
  if(!state.steps.length){box.innerHTML='<div class="builder-empty">Цепочка пока пустая. Нажмите слева “+ REST-вызов”, “+ Kafka-событие” или выберите сценарий выше.</div>'; syncLegacyTables(); return;}
  box.innerHTML=state.steps.map(s=>`<article class="chain-component" draggable="true" data-step-id="${s.id}"><div class="component-header"><div class="component-title"><span class="step-number">Шаг ${s.order}</span><span class="channel-chip">${labelOf(CH,s.channel)}</span></div><div class="component-actions"><button type="button" class="iconbtn" title="Вставить до" data-action="insert-before" data-id="${s.id}">+ до</button><button type="button" class="iconbtn" title="Выше" data-action="move-step" data-id="${s.id}" data-dir="-1">↑</button><button type="button" class="iconbtn" title="Ниже" data-action="move-step" data-id="${s.id}" data-dir="1">↓</button><button type="button" class="iconbtn" title="Копировать" data-action="duplicate-step" data-id="${s.id}">⧉</button><button type="button" class="iconbtn" title="Вставить после" data-action="insert-after" data-id="${s.id}">+ после</button><button type="button" class="iconbtn" title="Безопасные настройки" data-action="safe-step" data-id="${s.id}">✓</button><button type="button" class="iconbtn" title="Удалить" data-action="delete-step" data-id="${s.id}">×</button></div></div><label>Что происходит?</label><input value="${esc(s.name)}" data-step-field="name" data-id="${s.id}" placeholder="Например: Банк отправляет документы в УК"><div class="component-grid"><div><label>Откуда?</label><input list="syslist" value="${esc(s.source_system)}" data-step-field="source_system" data-id="${s.id}" placeholder="Источник"></div><div><label>Кто выполняет?</label><input list="syslist" value="${esc(s.system)}" data-step-field="system" data-id="${s.id}" placeholder="Сервис-исполнитель"></div><div><label>Куда?</label><input list="syslist" value="${esc(s.target_system)}" data-step-field="target_system" data-id="${s.id}" placeholder="Получатель"></div></div><label>Канал</label><div class="chip-select">${channelChips(s)}</div><div class="component-grid"><div><label>Ждёт ответ?</label><select data-step-field="blocking" data-id="${s.id}"><option value="yes" ${s.blocking!=='no'?'selected':''}>Да, ждёт</option><option value="no" ${s.blocking==='no'?'selected':''}>Нет, асинхронно</option></select></div><div><label>Что меняется?</label><select data-step-field="writes_entity" data-id="${s.id}"><option value="no" ${s.writes_entity!=='yes'?'selected':''}>Не меняет основную сущность</option><option value="yes" ${s.writes_entity==='yes'?'selected':''}>Создаёт/обновляет сущность</option></select></div><div><label>Что делать при ошибке?</label><select data-step-field="failure_policy" data-id="${s.id}"><option ${s.failure_policy==='Повторить автоматически'?'selected':''}>Повторить автоматически</option><option ${s.failure_policy==='DLQ / replay'?'selected':''}>DLQ / replay</option><option ${s.failure_policy==='DLQ / ручной разбор'?'selected':''}>DLQ / ручной разбор</option><option ${s.failure_policy==='Откатить / компенсировать'?'selected':''}>Откатить / компенсировать</option><option ${s.failure_policy==='Ручной разбор'?'selected':''}>Ручной разбор</option><option ${s.failure_policy==='Пока не знаю'?'selected':''}>Пока не знаю</option></select></div></div><details class="details-panel advanced-only"><summary>Технические настройки</summary><div class="component-grid"><div><label>Timeout, мс</label><input value="${esc(s.timeout_ms)}" data-step-field="timeout_ms" data-id="${s.id}" inputmode="numeric" placeholder="500"></div><div><label>Повтор при ошибке</label><select data-step-field="retry" data-id="${s.id}">${optPairs(RETRY,s.retry)}</select></div><div><label>Что считать повтором</label><select data-step-field="idempotency" data-id="${s.id}">${optPairs(IDEM,s.idempotency)}</select></div><div><label>После какого шага?</label><input value="${esc(s.depends_on)}" data-step-field="depends_on" data-id="${s.id}" placeholder="1 или 1,2"></div><div><label>Как восстановиться?</label><input value="${esc(s.compensation)}" data-step-field="compensation" data-id="${s.id}" placeholder="DLQ, replay, compensation"></div><div><label>Тип компонента</label><input value="${esc(s.component_type)}" data-step-field="component_type" data-id="${s.id}" placeholder="action/event/storage"></div></div></details></article>`).join('');
  syncLegacyTables();
}
function stepIssue(s){if(!s.system)return 'Нет исполнителя'; if(!s.target_system)return 'Нет получателя'; if(SYNC.has(s.channel)&&s.blocking!=='no'&&!s.timeout_ms)return 'REST/Sync без timeout'; if(ASYNC.has(s.channel)&&!s.compensation&&s.retry==='none')return 'Нет recovery'; return ''}
function renderProcessMap(){
  const box=document.getElementById('processMap'); if(!box)return;
  if(!state.steps.length){box.innerHTML='<div class="builder-empty">Карта появится после добавления шагов.</div>';return;}
  box.innerHTML=state.steps.map((s,i)=>{const issue=stepIssue(s); const badge=issue?`<span class="badge warn">Нужно проверить</span>`:'<span class="badge" style="color:var(--good)">ok</span>'; return `<div class="map-node"><b>${s.order}. ${esc(s.name||'Без названия')}</b><span>${esc(s.source_system||'Источник не указан')} → ${esc(labelOf(CH,s.channel))} → ${esc(s.system||'Исполнитель не указан')} → ${esc(s.target_system||'Получатель не указан')}</span><small>${s.blocking==='no'?'async':'sync'} · ${s.timeout_ms?('timeout '+esc(s.timeout_ms)+' мс'):'timeout не указан'} · ${s.compensation?'recovery есть':'recovery не описан'} ${badge}</small></div>${i<state.steps.length-1?'<div class="map-arrow">↓</div>':''}`}).join('');
}
function readiness(){
  const restNoTimeout=state.steps.filter(s=>SYNC.has(s.channel)&&s.blocking!=='no'&&!s.timeout_ms).length;
  const asyncNoRecovery=state.steps.filter(s=>ASYNC.has(s.channel)&&!s.compensation&&s.retry==='none').length;
  const noTarget=state.steps.filter(s=>!s.target_system).length;
  const noSystem=state.steps.filter(s=>!s.system).length;
  const writers=state.steps.filter(s=>s.writes_entity==='yes').length;
  const missing=[]; if(!v('p_entity'))missing.push('основная сущность'); if(!v('p_lookup'))missing.push('ключ поиска'); if(!v('p_statuses'))missing.push('статусы');
  return {restNoTimeout,asyncNoRecovery,noTarget,noSystem,writers,missing};
}
function renderReadiness(){
  const box=document.getElementById('readinessPanel'); if(!box)return; const r=readiness();
  const items=[['Систем',state.systems.length,state.systems.length>=2?'ok':'warn'],['Шагов',state.steps.length,state.steps.length>=2?'ok':'warn'],['REST/Sync без timeout',r.restNoTimeout,r.restNoTimeout?'fail':'ok'],['Async без восстановления',r.asyncNoRecovery,r.asyncNoRecovery?'fail':'ok'],['Шагов без получателя',r.noTarget,r.noTarget?'warn':'ok'],['Шагов без исполнителя',r.noSystem,r.noSystem?'fail':'ok'],['Шагов, меняющих сущность',r.writers,r.writers>1?'warn':'ok'],['Ключ/статусы/сущность',r.missing.length?r.missing.join(', '):'заполнены',r.missing.length?'warn':'ok']];
  const severe=r.restNoTimeout+r.asyncNoRecovery+r.noSystem; const msg=severe?'Разбор можно запустить, но сначала лучше исправить красные пункты.':'Можно запускать разбор. Жёлтые пункты можно уточнить для качества.';
  box.innerHTML=`<p class="hint"><b>${msg}</b></p><div class="readiness-list">`+items.map(([k,v,st])=>`<div class="readiness-item"><b>${esc(k)}</b><span class="status-dot ${st}">${esc(String(v))}</span></div>`).join('')+'</div>';
  const sub=document.getElementById('submitHint'); if(sub) sub.textContent=msg;
}
function updateReview(){const box=document.getElementById('reviewBox'); if(!box)return; const async=state.steps.filter(s=>ASYNC.has(s.channel)).length; box.innerHTML=`<div class="metric"><b>${state.systems.length}</b><span>систем участвует</span></div><div class="metric"><b>${state.steps.length}</b><span>шагов описано</span></div><div class="metric"><b>${async}</b><span>асинхронных границ</span></div>`;}
function updateGuidance(){
  const g=document.getElementById('liveGuide'); if(!g)return; const issues=[]; const r=readiness();
  if(!v('p_name'))issues.push('Назовите процесс простыми словами.'); if(!v('p_entity'))issues.push('Укажите основную сущность: заявка, документ, договор, платёж или операция.'); if(!v('p_goal'))issues.push('Опишите бизнес-цель одним предложением.'); if(!v('p_lookup'))issues.push('Заполните ключ поиска и дедупликации.'); if(state.systems.length<2)issues.push('Добавьте минимум две системы-участника.'); if(state.steps.length<2)issues.push('Добавьте цепочку хотя бы из двух шагов.'); if(r.asyncNoRecovery)issues.push(`У ${r.asyncNoRecovery} асинхронных шагов нет понятного восстановления: DLQ, replay, Inbox или ручной разбор.`); if(r.restNoTimeout)issues.push(`У ${r.restNoTimeout} синхронных шагов нет timeout.`);
  if(!issues.length){g.className='assist ok';g.innerHTML='<b>Вводные выглядят хорошо.</b><p>Можно запускать разбор. Для production-проверки включите экспертный режим и уточните timeout, retry, идемпотентность и recovery.</p>';return;}
  g.className='assist warn';g.innerHTML='<b>Что ещё заполнить:</b><ul>'+issues.map(x=>`<li>${esc(x)}</li>`).join('')+'</ul>';
}
function updateProgress(){
  const essentials=[v('p_name'),v('p_entity'),v('p_goal'),v('p_statuses'),v('p_fields'),v('p_lookup')];
  let done=essentials.filter(Boolean).length+Math.min(state.systems.length,2)+Math.min(state.steps.length,3);
  const pct=Math.min(100,Math.round(done/11*100)); const bar=document.querySelector('#fillbar i'); if(bar)bar.style.width=pct+'%';
  const text=document.getElementById('filltext'); if(text)text.textContent=pct<50?'Сначала выберите сценарий и добавьте участников цепочки.':pct<80?'Уже достаточно для первичного разбора. Для качества проверьте ключ, статусы и восстановление.':'Вводные достаточно полные для полезного разбора.';
  updateGuidance(); updateReview(); renderReadiness(); renderProcessMap(); syncLegacyTables();
}
function renderAll(){renderSysList(); renderSystems(); renderSteps(); renderProcessMap(); renderReadiness(); updateProgress();}
function syncLegacyTables(){
  const sys=document.querySelector('#systems tbody'); if(sys) sys.innerHTML=state.systems.map(s=>`<tr><td><input name="sname" value="${esc(s.name)}"></td><td><select name="srole"><option value="${esc(s.role)}" selected>${esc(s.role)}</option></select></td><td><input name="sowner" value="${esc(s.owner)}"></td><td><input name="scrit" value="${esc(s.criticality)}"></td><td><input name="sstab" value="${esc(s.stability)}"></td><td><input name="slimit" value="${esc(s.rate_limit_rps)}"></td></tr>`).join('');
  const steps=document.querySelector('#steps tbody'); if(steps) steps.innerHTML=state.steps.map(s=>`<tr><td><input name="order" value="${s.order}"></td><td><input name="name" value="${esc(s.name)}"></td><td><input name="source_system" value="${esc(s.source_system)}"></td><td><input name="system" value="${esc(s.system)}"></td><td><input name="target_system" value="${esc(s.target_system)}"></td><td><input name="channel" value="${esc(s.channel)}"></td><td><input name="blocking" value="${esc(s.blocking)}"></td><td><input name="timeout_ms" value="${esc(s.timeout_ms)}"></td><td><input name="retry" value="${esc(s.retry)}"></td><td><input name="idempotency" value="${esc(s.idempotency)}"></td><td><input name="writes_entity" value="${esc(s.writes_entity)}"></td><td><input name="depends_on" value="${esc(s.depends_on)}"></td><td><input name="compensation" value="${esc(s.compensation)}"></td></tr>`).join('');
}
function buildPayload(){return {meta:{name:v('p_name'),entity:v('p_entity'),goal:v('p_goal'),description:v('p_description'),lookup_keys:v('p_lookup'),constraints:v('p_constraints'),customer_visible:v('p_visible'),money:v('p_money'),regulatory:v('p_reg'),sla_ms:v('p_sla'),read_freq:v('p_read'),ordering:v('p_order'),statuses:v('p_statuses'),fields:v('p_fields'),load_rps:v('p_rps'),peak_factor:v('p_peak'),multi_tenant:v('p_tenant'),replacing_legacy:v('p_legacy')},systems:state.systems.map(s=>({name:s.name,role:s.role,owner:s.owner,criticality:s.criticality,stability:s.stability,rate_limit_rps:s.rate_limit_rps})),steps:state.steps.map((s,idx)=>({order:idx+1,name:s.name,source_system:s.source_system,system:s.system,target_system:s.target_system,channel:s.channel,blocking:s.blocking,timeout_ms:s.timeout_ms,retry:s.retry,idempotency:s.idempotency,writes_entity:s.writes_entity,depends_on:s.depends_on,compensation:s.compensation,failure_policy:s.failure_policy,component_type:s.component_type}))};}
function clearAll(){state.systems=[]; state.steps=[];}
function suggestBasics(){if(!v('p_statuses'))setv('p_statuses','CREATED, PROCESSING, COMPLETED, REJECTED, FAILED, NEEDS_MANUAL_REVIEW'); if(!v('p_fields'))setv('p_fields','requestId:string|required|unique, correlationId:uuid|required|indexed, eventId:uuid|required|unique, status:string|required, createdAt:datetime|required, updatedAt:datetime|required'); if(!v('p_lookup'))setv('p_lookup','requestId + operationType + targetSystem; eventId для дедупликации событий'); updateProgress();}
function setBasics(vals){Object.entries(vals).forEach(([k,val])=>setv('p_'+k,val));}
function resetScenarioSelection(){document.querySelectorAll('.scenario').forEach(b=>{b.classList.remove('active');b.setAttribute('aria-pressed','false')}); const selected=document.getElementById('selectedScenario'); if(selected)selected.textContent='Сценарий ещё не выбран.';}
function showToast(message){let t=document.getElementById('toast'); if(!t){t=document.createElement('div');t.id='toast';t.className='toast';t.setAttribute('role','status');document.body.appendChild(t)} t.textContent=message; t.classList.add('show'); clearTimeout(t._timer); t._timer=setTimeout(()=>t.classList.remove('show'),3200);}
function selectScenario(kind,button){applyScenario(kind); document.querySelectorAll('.scenario').forEach(b=>{const active=b===button;b.classList.toggle('active',active);b.setAttribute('aria-pressed',active?'true':'false')}); const label=button?.querySelector('b')?.textContent||'Сценарий'; const selected=document.getElementById('selectedScenario'); if(selected)selected.textContent=kind==='blank'?'Пустой процесс. Добавьте участников и компоненты цепочки.':'Выбран сценарий: '+label+'. Теперь проверьте сущность, ключ, участников и цепочку.'; showToast(kind==='blank'?'Форма очищена.':'Сценарий подставлен карточками. Цепочку можно двигать, копировать и удалять.'); if(kind!=='blank')document.getElementById('chain-builder')?.scrollIntoView({behavior:'smooth',block:'start'});}
function applyScenario(kind){
  clearAll(); setBasics({name:'',entity:'',goal:'',description:'',lookup:'',constraints:'',sla:'',statuses:'',fields:'',visible:'no',money:'no',reg:'no',order:'no',rps:'',peak:'1',tenant:'no',legacy:'no',read:'medium'});
  if(kind==='blank'){renderAll();return;}
  if(kind==='reverse'){
    setBasics({name:'Обратный поток статусов между банком и УК',entity:'ApplicationStatus',goal:'Банк передаёт документы в УК и получает обратно понятные статусы обработки документов и операций.',visible:'mixed',money:'direct',reg:'yes',order:'per_entity',statuses:'CREATED, SENT_TO_UK, RECEIVED_BY_UK, PROCESSING, COMPLETED, REJECTED, ERROR',fields:'applicationId:uuid|required|indexed, documentId:string|required, operationId:string, status:string|required, eventId:uuid|required|unique, correlationId:uuid|required|indexed, occurredAt:datetime|required',lookup:'applicationId + documentId или operationId, eventId для дедупликации',description:'Банк передаёт документы и операции в УК. УК возвращает обратный поток статусов, чтобы банк видел финал обработки и расследовал зависшие заявки.'});
    [['Банк','internal','Команда банка','critical','stable'],['УК','external','Управляющая компания','critical','limited'],['Kafka','broker','Платформа','high','stable'],['БД банка','db','Команда банка','critical','stable']].forEach(s=>addSystem({name:s[0],role:s[1],owner:s[2],criticality:s[3],stability:s[4]},false));
    [{name:'Банк создаёт заявку и документы',source_system:'Клиент/офис',system:'Банк',target_system:'БД банка',channel:'db',timeout_ms:'300',idempotency:'key',writes_entity:'yes'}, {name:'Банк передаёт документы в УК',source_system:'Банк',system:'Банк',target_system:'УК',channel:'rest',timeout_ms:'2000',retry:'auto',idempotency:'key',compensation:'timeout, повтор с тем же idempotencyKey'}, {name:'УК публикует статус документа',source_system:'УК',system:'УК',target_system:'Kafka',channel:'kafka',blocking:'no',retry:'auto',idempotency:'key',compensation:'outbox, DLQ, replay'}, {name:'Банк принимает статус и обновляет историю',source_system:'Kafka',system:'Банк',target_system:'БД банка',channel:'kafka',blocking:'no',retry:'auto',idempotency:'key',writes_entity:'yes',compensation:'inbox-дедупликация, история статусов'}].forEach(x=>addStep(x,null,false));
  } else if(kind==='kafka'){
    setBasics({name:'Публикация событий об изменении договора',entity:'Contract',goal:'Исходный сервис публикует изменения договора, а потребители получают их через Kafka без потери и дублей.',order:'per_entity',statuses:'CHANGED, CANCELLED, ERROR',fields:'contractId:uuid|required|indexed, eventId:uuid|required|unique, eventVersion:string|required, correlationId:uuid|required|indexed, occurredAt:datetime|required',lookup:'contractId для порядка по сущности, eventId для дедупликации',description:'Исходный сервис меняет договор, публикует событие, а несколько потребителей обрабатывают его независимо.'});
    [['Сервис договоров','internal','Команда договоров','critical','stable'],['Kafka','broker','Платформа','high','stable'],['Потребитель','internal','Команда потребителя','medium','stable'],['БД договоров','db','Команда договоров','high','stable']].forEach(s=>addSystem({name:s[0],role:s[1],owner:s[2],criticality:s[3],stability:s[4]},false));
    [{name:'Сервис договоров сохраняет изменение',source_system:'API',system:'Сервис договоров',target_system:'БД договоров',channel:'db',timeout_ms:'200',writes_entity:'yes',idempotency:'natural'}, {name:'Сервис договоров публикует событие через Outbox',source_system:'Сервис договоров',system:'Сервис договоров',target_system:'Kafka',channel:'kafka',blocking:'no',retry:'auto',idempotency:'key',compensation:'outbox, DLQ, replay'}, {name:'Потребитель обрабатывает событие',source_system:'Kafka',system:'Потребитель',target_system:'Своя БД/проекция',channel:'kafka',blocking:'no',retry:'auto',idempotency:'key',compensation:'inbox-дедупликация'}].forEach(x=>addStep(x,null,false));
  } else if(kind==='enrichment'){
    setBasics({name:'Обогащение события через REST-сервис',entity:'EnrichedEvent',goal:'Событие из Kafka нужно дополнить данными из REST-сервиса и передать дальше без потери сообщений.',constraints:'Kafka одна, новый сервис дорогой, REST-справочник может быть недоступен.',statuses:'RECEIVED, ENRICHING, ENRICHED, PUBLISHED, FAILED, DLQ',fields:'eventId:uuid|required|unique, sourceId:string|required|indexed, enrichmentVersion:string, correlationId:uuid|required|indexed',lookup:'eventId для дедупликации, sourceId + enrichmentVersion для проверки актуальности',description:'Потребитель читает событие, вызывает REST-справочник, обогащает payload и публикует enriched-event. Нужно решить, где ответственность и что делать при недоступности REST.'});
    [['Kafka','broker','Платформа','critical','stable'],['Enrichment service','internal','Команда интеграций','high','stable'],['REST-справочник','external','Владелец справочника','high','limited'],['Enriched topic','broker','Платформа','high','stable']].forEach(s=>addSystem({name:s[0],role:s[1],owner:s[2],criticality:s[3],stability:s[4]},false));
    [{name:'Enrichment service читает исходное событие',source_system:'Kafka',system:'Enrichment service',target_system:'Enrichment service',channel:'kafka',blocking:'no',retry:'auto',idempotency:'key',compensation:'Inbox, DLQ, replay'}, {name:'Enrichment service вызывает REST-справочник',source_system:'Enrichment service',system:'Enrichment service',target_system:'REST-справочник',channel:'rest',blocking:'yes',timeout_ms:'700',retry:'auto',idempotency:'key',compensation:'timeout, fallback/cache, circuit breaker'}, {name:'Enrichment service публикует enriched-event',source_system:'Enrichment service',system:'Enrichment service',target_system:'Enriched topic',channel:'kafka',blocking:'no',retry:'auto',idempotency:'key',compensation:'Outbox, DLQ, replay'}].forEach(x=>addStep(x,null,false));
  } else if(kind==='dwh'){
    setBasics({name:'Передача изменений в DWH через CDC',entity:'BusinessRecord',goal:'Передавать данные в аналитику без синхронного чтения production-БД и без нагрузки на основной бизнес-процесс.',statuses:'CAPTURED, TRANSFORMED, LOADED, RECONCILED, FAILED',fields:'recordId:uuid|required|indexed, updatedAt:datetime|required, lsn:string|required|unique, batchId:string|indexed',lookup:'recordId + updatedAt, LSN/watermark для CDC',description:'Данные из OLTP должны попадать в DWH через CDC/ETL, с контролем полноты, freshness, watermark и backfill.'});
    [['OLTP БД','db','Команда продукта','critical','stable'],['CDC-пайплайн','internal','Платформа данных','high','stable'],['DWH','analytics','Команда данных','medium','stable']].forEach(s=>addSystem({name:s[0],role:s[1],owner:s[2],criticality:s[3],stability:s[4]},false));
    [{name:'Бизнес-сервис пишет данные в OLTP БД',source_system:'Бизнес-сервис',system:'OLTP БД',target_system:'OLTP БД',channel:'db',timeout_ms:'200',writes_entity:'yes',idempotency:'natural'}, {name:'CDC-пайплайн забирает изменения',source_system:'OLTP БД',system:'CDC-пайплайн',target_system:'DWH',channel:'cdc',blocking:'no',retry:'auto',idempotency:'natural',compensation:'повтор чтения, контроль lag, watermark'}, {name:'DWH строит витрину и сверяет полноту',source_system:'CDC-пайплайн',system:'DWH',target_system:'DWH',channel:'batch',blocking:'no',retry:'manual',idempotency:'natural',compensation:'reconciliation-сверка, backfill'}].forEach(x=>addStep(x,null,false));
  } else if(kind==='highload'){
    setBasics({name:'Highload consumer из Kafka в Postgres',entity:'FilteredEvent',goal:'Консьюмеры читают общий топик, фильтруют события и сохраняют только нужные записи в Postgres.',rps:'5000',peak:'5',order:'per_entity',statuses:'RECEIVED, STORED, SKIPPED, FAILED',fields:'eventId:uuid|required|unique, aggregateId:string|required|indexed, eventType:string|required, receivedAt:datetime|required',lookup:'eventId для дедупликации, aggregateId + eventType для бизнес-поиска',description:'Консьюмер читает общий топик, фильтрует только нужные события и сохраняет результат в Postgres. Нужно контролировать lag, backpressure и filter ratio.'});
    [['Kafka','broker','Платформа','critical','stable'],['Consumer group','internal','Команда интеграций','high','stable'],['Postgres','db','DBA','high','stable']].forEach(s=>addSystem({name:s[0],role:s[1],owner:s[2],criticality:s[3],stability:s[4]},false));
    [{name:'Консьюмер читает пачку событий',source_system:'Kafka',system:'Consumer group',target_system:'Consumer group',channel:'kafka',blocking:'no',retry:'auto',idempotency:'key',compensation:'контроль offset/ack, backpressure'}, {name:'Консьюмер фильтрует события по признаку',source_system:'Consumer group',system:'Consumer group',target_system:'Consumer group',channel:'kafka',blocking:'no',retry:'auto',idempotency:'key',compensation:'метрики filter ratio, skip reason'}, {name:'Консьюмер сохраняет нужные события в Postgres',source_system:'Consumer group',system:'Consumer group',target_system:'Postgres',channel:'db',timeout_ms:'300',retry:'auto',idempotency:'key',writes_entity:'yes',compensation:'unique key, DLQ, replay'}].forEach(x=>addStep(x,null,false));
  } else if(kind==='dispatcher'){
    setBasics({name:'Универсальный докатчик запросов в системы А и Б',entity:'DispatchOperation',goal:'Один универсальный сервис отправляет запросы в разные целевые системы в рамках одного бизнес-процесса и должен корректно различать подоперации.',description:'Сервис используется несколькими процессами. Для связи используется operUid, но в одном процессе запрос в систему А и запрос в систему Б могут иметь одинаковый operUid. Поиск только по operUid склеит разные записи. Нужен operationType и targetSystem.',lookup:'operUid + operationType + targetSystem',constraints:'Сервис универсальный, менять внешние системы дорого, нужно сохранить совместимость старых вызовов.',visible:'no',order:'per_entity',statuses:'CREATED, SENT_TO_TARGET, ACCEPTED_BY_TARGET, COMPLETED, REJECTED, FAILED, NEEDS_MANUAL_REVIEW',fields:'operUid:string|required|indexed, operationType:string|required|indexed, targetSystem:string|required|indexed, requestId:uuid|required|unique, correlationId:uuid|required|indexed, status:string|required'});
    [['Инициатор процесса','internal','Команда продукта','high','stable'],['Универсальный докатчик','internal','Команда интеграций','critical','stable'],['Система А','external','Владелец системы А','high','limited'],['Система Б','external','Владелец системы Б','high','limited'],['БД докатчика','db','Команда интеграций','critical','stable']].forEach(s=>addSystem({name:s[0],role:s[1],owner:s[2],criticality:s[3],stability:s[4]},false));
    [{name:'Инициатор создаёт бизнес-процесс с одним operUid',source_system:'Пользователь/процесс',system:'Инициатор процесса',target_system:'Универсальный докатчик',channel:'rest',timeout_ms:'300',idempotency:'key',writes_entity:'yes'}, {name:'Докатчик создаёт запись подоперации для системы А',source_system:'Универсальный докатчик',system:'Универсальный докатчик',target_system:'БД докатчика',channel:'db',timeout_ms:'200',retry:'auto',idempotency:'natural',writes_entity:'yes',compensation:'unique key: operUid + operationType + targetSystem'}, {name:'Докатчик отправляет запрос в систему А',source_system:'Универсальный докатчик',system:'Универсальный докатчик',target_system:'Система А',channel:'rest',timeout_ms:'1500',retry:'auto',idempotency:'key',compensation:'timeout, retry, manual recovery'}, {name:'Докатчик создаёт запись подоперации для системы Б с тем же operUid',source_system:'Универсальный докатчик',system:'Универсальный докатчик',target_system:'БД докатчика',channel:'db',timeout_ms:'200',retry:'auto',idempotency:'natural',writes_entity:'yes',compensation:'unique key: operUid + operationType + targetSystem'}, {name:'Докатчик отправляет запрос в систему Б',source_system:'Универсальный докатчик',system:'Универсальный докатчик',target_system:'Система Б',channel:'rest',timeout_ms:'1500',retry:'auto',idempotency:'key',compensation:'timeout, retry, manual recovery'}].forEach(x=>addStep(x,null,false));
  }
  renumberSteps(); renderAll();
}
function setMode(mode){state.mode=mode; document.body.classList.toggle('quick-mode',mode==='quick'); document.querySelectorAll('[data-mode]').forEach(b=>{const active=b.dataset.mode===mode;b.classList.toggle('active',active);b.setAttribute('aria-pressed',active?'true':'false')});}
async function submitForm(){const payload=buildPayload(); const box=document.getElementById('errors'); if(box)box.innerHTML=''; renderReadiness(); try{const r=await fetch(appUrl('/api/analyze'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}); const d=await r.json(); if(d.ok){location.href=appUrl('/run/'+d.id)}else{(d.errors||['Неизвестная ошибка']).forEach(e=>{const el=document.createElement('div');el.className='err';el.textContent=e;box?.appendChild(el)})}}catch(e){const el=document.createElement('div');el.className='err';el.textContent='Сервер недоступен: '+e;box?.appendChild(el)}}
function demo(){selectScenario('reverse',document.querySelector('[data-scenario="reverse"]'))}
function highlightNav(selector){const links=[...document.querySelectorAll(selector+' a[href^="#"]')]; if(!links.length||!('IntersectionObserver' in window))return; const byId=new Map(links.map(a=>[a.getAttribute('href').slice(1),a])); const obs=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){links.forEach(a=>a.classList.remove('active'));byId.get(entry.target.id)?.classList.add('active');}})},{rootMargin:'-96px 0px -65% 0px',threshold:0.01}); byId.forEach((_,id)=>{const node=document.getElementById(id);if(node)obs.observe(node)});}
document.addEventListener('input',e=>{const sf=e.target.closest('[data-system-field]'); if(sf){updateSystem(sf.dataset.id,sf.dataset.systemField,sf.value);return;} const st=e.target.closest('[data-step-field]'); if(st){updateStep(st.dataset.id,st.dataset.stepField,st.value);return;} updateProgress();});
document.addEventListener('change',e=>{const sf=e.target.closest('[data-system-field]'); if(sf){updateSystem(sf.dataset.id,sf.dataset.systemField,sf.value);return;} const st=e.target.closest('[data-step-field]'); if(st){updateStep(st.dataset.id,st.dataset.stepField,st.value);return;} updateProgress();});
document.addEventListener('click',e=>{const el=e.target.closest('[data-action]'); if(!el)return; const a=el.dataset.action; if(a==='scenario')return selectScenario(el.dataset.scenario,el); if(a==='mode')return setMode(el.dataset.mode); if(a==='clear')return selectScenario('blank',document.querySelector('[data-scenario="blank"]')); if(a==='add-system')return presetSystem(el.dataset.systemKind||'internal'); if(a==='add-step')return addStep(presetStep(el.dataset.template||'rest')); if(a==='template')return addStep(presetStep(el.dataset.template)); if(a==='safe-all'){applySafeDefaultsAll();return showToast('Безопасные настройки применены ко всем компонентам.')} if(a==='suggest-basics'){suggestBasics();return showToast('Базовые статусы, поля и ключи подставлены.')} if(a==='demo')return demo(); if(a==='submit')return submitForm(); if(a==='delete-system')return deleteSystem(el.dataset.id); if(a==='delete-step')return deleteStep(el.dataset.id); if(a==='duplicate-step')return duplicateStep(el.dataset.id); if(a==='move-step')return moveStep(el.dataset.id,parseInt(el.dataset.dir||'0',10)); if(a==='insert-after')return insertStepAfter(el.dataset.id,'rest'); if(a==='insert-before')return insertStepBefore(el.dataset.id,'rest'); if(a==='safe-step')return applySafeDefaultsToStep(el.dataset.id); if(a==='set-channel')return updateStep(el.dataset.id,'channel',el.dataset.channel);});
document.addEventListener('dragstart',e=>{const c=e.target.closest('.chain-component'); if(!c)return; dragStepId=c.dataset.stepId; c.classList.add('dragging'); e.dataTransfer.effectAllowed='move';});
document.addEventListener('dragend',e=>{document.querySelectorAll('.chain-component').forEach(x=>x.classList.remove('dragging','drop-target')); dragStepId=null;});
document.addEventListener('dragover',e=>{const c=e.target.closest('.chain-component'); if(!c||!dragStepId)return; e.preventDefault(); c.classList.add('drop-target');});
document.addEventListener('dragleave',e=>{e.target.closest('.chain-component')?.classList.remove('drop-target');});
document.addEventListener('drop',e=>{const c=e.target.closest('.chain-component'); if(!c||!dragStepId)return; e.preventDefault(); const from=state.steps.findIndex(s=>s.id===dragStepId); const to=state.steps.findIndex(s=>s.id===c.dataset.stepId); if(from<0||to<0||from===to)return; const [x]=state.steps.splice(from,1); state.steps.splice(to,0,x); renumberSteps(); renderAll();});
window.addEventListener('DOMContentLoaded',()=>{document.documentElement.classList.add('js-ready'); setMode('quick'); applyScenario('blank'); resetScenarioSelection(); document.querySelectorAll('input,select,textarea').forEach(e=>e.addEventListener('input',updateProgress)); highlightNav('.guidebar'); highlightNav('.resultnav'); updateProgress();});
"""


def page(title, body, extra_head=''):
    return f"""<!doctype html><html lang="ru" data-base-path="{escape(BASE_PATH)}"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{escape(title)}</title><style>{CSS}</style>{extra_head}</head>
<body><div class="wrap"><noscript><div class="err">Для работы конструктора нужен JavaScript. Включите JavaScript или проверьте политики браузера.</div></noscript>{body}</div></body></html>"""


def titleblock(sub, active='builder'):
    builder_cls = 'primary' if active == 'builder' else ''
    inv_cls = 'primary' if active == 'invariants' else ''
    return f"""
    <header class="titleblock">
      <div>
        <h1>Интеграционный проектировщик</h1>
        <nav class="topnav" aria-label="Основная навигация">
          <a class="{builder_cls}" href="{url_for('/')}">Конструктор процесса</a>
          <a class="{inv_cls}" href="{url_for('/invariants')}">Справочник инвариантов</a>
        </nav>
      </div>
      <div class="meta">ЛИСТ: {escape(sub)}<br>РЕВ. {APP_VERSION} · rule-engine · без LLM</div>
    </header>
    """

def form_page():
    body = titleblock('КОНСТРУКТОР ПРОЦЕССА · ГИБКАЯ ЦЕПОЧКА', active='builder') + f"""
<section class="hero">
 <h2>Соберите интеграционный процесс как понятную цепочку.</h2>
 <p>Выберите готовый сценарий или добавляйте компоненты вручную: REST, Kafka, БД, webhook, batch, CDC. Каждый компонент можно двигать, копировать, вставлять до/после и удалять. Rule-engine получает тот же совместимый JSON.</p>
 <div class="steps3"><div class="stepbox"><b>1. Сценарий</b><br>Подставляем основу процесса.</div><div class="stepbox"><b>2. Цепочка</b><br>Двигаем компоненты, связываем системы и recovery.</div><div class="stepbox"><b>3. Разбор</b><br>Получаем риски, gates, чек-лист и артефакты.</div></div>
 <div class="navlinks"><a href="{url_for('/invariants')}">Открыть справочник инвариантов</a><a href="{url_for('/')}">Конструктор процесса</a></div>
</section>

<nav class="guidebar" aria-label="Навигация по проектированию"><span class="guide-title">Проектирование:</span><a href="#scenario">1. сценарий</a><a href="#basics">2. смысл</a><a href="#chain-builder">3. цепочка</a><a href="#readiness">4. проверка</a></nav>

<section class="card">
 <div class="toolbar">
  <div class="mode" aria-label="Режим заполнения"><button type="button" data-action="mode" data-mode="quick">Простой режим</button><button type="button" data-action="mode" data-mode="advanced">Экспертный режим</button></div>
  <span class="spacer"></span>
  <button type="button" class="btn ghost" data-action="clear">очистить</button>
 </div>
 <p class="hint quick-note">В простом режиме видны только человеческие поля. Технические настройки остаются в payload и доступны в экспертном режиме.</p>
 <p class="hint advanced-note">В экспертном режиме доступны timeout, retry, идемпотентность, зависимости, компенсации, критичность и лимиты.</p>
 <div class="progress" id="fillbar"><i></i></div><p class="hint" id="filltext"></p><div id="liveGuide" class="assist"></div>
</section>

<section class="card" id="scenario"><h2>1. Выберите ближайший сценарий</h2>
 <div class="scenarios">
  <button type="button" class="scenario" data-action="scenario" data-scenario="reverse" aria-pressed="false"><b>Обратный поток статусов</b><span>Банк ↔ УК, статусы документов и операций.</span></button>
  <button type="button" class="scenario" data-action="scenario" data-scenario="kafka" aria-pressed="false"><b>События через Kafka</b><span>Публикация изменений, Outbox, Inbox, DLQ.</span></button>
  <button type="button" class="scenario" data-action="scenario" data-scenario="enrichment" aria-pressed="false"><b>Обогащение данных</b><span>Kafka + REST к внешней системе + enriched-event.</span></button>
  <button type="button" class="scenario" data-action="scenario" data-scenario="dwh" aria-pressed="false"><b>DWH / CDC / витрина</b><span>Передача данных в аналитику без нагрузки на core-flow.</span></button>
  <button type="button" class="scenario" data-action="scenario" data-scenario="highload" aria-pressed="false"><b>Highload consumer</b><span>Фильтрация общего топика и запись в Postgres.</span></button>
  <button type="button" class="scenario" data-action="scenario" data-scenario="dispatcher" aria-pressed="false"><b>Универсальный докатчик</b><span>Один operUid, разные operationType и целевые системы.</span></button>
  <button type="button" class="scenario" data-action="scenario" data-scenario="blank" aria-pressed="false"><b>С нуля</b><span>Пустая форма для нестандартного процесса.</span></button>
 </div>
 <p id="selectedScenario" class="selected-scenario">Сценарий ещё не выбран.</p>
</section>

<section class="card" id="basics"><h2>2. Коротко опишите смысл процесса</h2>
 <p class="hint">Заполните минимум: название, сущность, бизнес-цель, ключ поиска, статусы. Остальное можно оставить по умолчанию.</p><div class="minimal"><div class="mini"><b>Сущность</b><span>что меняется в процессе</span></div><div class="mini"><b>Ключ</b><span>по чему искать и дедуплицировать</span></div><div class="mini"><b>Статусы</b><span>где процесс может зависнуть</span></div><div class="mini"><b>Ошибки</b><span>как восстановиться</span></div></div>
 <div class="grid g3">
  <div><label for="p_name">Как называется процесс?</label><input id="p_name" placeholder="Например: обратный поток статусов"></div>
  <div><label for="p_entity">Какая основная сущность?</label><input id="p_entity" placeholder="Например: заявка, договор, документ"><div class="fieldtip">То, вокруг чего строится процесс.</div></div>
  <div><label for="p_sla">Сколько можно ждать ответ?</label><input id="p_sla" inputmode="numeric" placeholder="мс; пусто, если процесс фоновый"><div class="fieldtip">Если клиент ждёт ответ — укажите SLA. Если обработка фоновая — можно оставить пустым.</div></div>
 </div>
 <label for="p_goal">Какую бизнес-задачу решает процесс?</label><input id="p_goal" placeholder="Например: банк должен видеть финальный статус обработки в УК">
 <label for="p_description">Краткое описание ситуации</label><textarea id="p_description" placeholder="Например: универсальный докатчик отправляет запросы в систему А и систему Б. В рамках одного процесса используется один operUid, поэтому поиск только по operUid может склеить разные записи."></textarea>
 <div class="grid g2">
  <div id="fix-lookup"><label for="p_lookup">По каким полям искать, обновлять и дедуплицировать запись?</label><input id="p_lookup" placeholder="Например: operUid + operationType + targetSystem"><div class="fieldtip">Для общих сервисов часто нужен составной ключ: requestId + operationType + targetSystem + tenantId.</div></div>
  <div id="fix-constraints"><label for="p_constraints">Какие ограничения или компромиссы есть?</label><input id="p_constraints" placeholder="Например: нельзя менять сервис А, новый топик запрещён, срок 2 недели"></div>
 </div>
 <div class="grid g4">
  <div><label for="p_visible">Кто ждёт результат?</label><select id="p_visible"><option value="no">Никто, процесс фоновый</option><option value="yes">Пользователь/клиент ждёт</option><option value="mixed">Смешанный вариант</option></select></div>
  <div><label for="p_money">Есть влияние на деньги?</label><select id="p_money"><option value="no">Нет</option><option value="indirect">Косвенно</option><option value="direct">Напрямую</option></select></div>
  <div><label for="p_reg">Есть регуляторный риск?</label><select id="p_reg"><option value="no">Нет</option><option value="yes">Да</option></select></div>
  <div><label for="p_order">Нужен порядок событий?</label><select id="p_order"><option value="no">Нет</option><option value="per_entity">В рамках одной сущности</option><option value="global">Глобальный порядок</option></select></div>
 </div>
 <div class="grid g3 advanced-only">
  <div><label for="p_rps">Средняя нагрузка, RPS</label><input id="p_rps" inputmode="numeric" placeholder="Например: 100"></div>
  <div><label for="p_peak">Пиковая нагрузка</label><select id="p_peak"><option value="1">x1</option><option value="2">x2</option><option value="5">x5</option><option value="10">x10</option></select></div>
  <div><label for="p_tenant">Один поток для разных клиентов?</label><select id="p_tenant"><option value="no">Нет</option><option value="yes">Да</option></select></div>
  <div><label for="p_legacy">Это замена legacy?</label><select id="p_legacy"><option value="no">Нет</option><option value="yes">Да</option></select></div>
  <div><label for="p_read">Как часто читают результат?</label><select id="p_read"><option value="low">Редко</option><option value="medium" selected>Средне</option><option value="high">Часто</option><option value="very_high">Очень часто</option></select></div>
 </div>
 <div class="grid g2">
  <div id="fix-statuses"><label for="p_statuses">Какие статусы есть у процесса?</label><input id="p_statuses" placeholder="Например: CREATED, PROCESSING, COMPLETED, REJECTED"><div class="fieldtip">Статусы показывают, где находится заявка и какие состояния финальные.</div></div>
  <div id="fix-fields"><label for="p_fields">Какие ключевые поля есть у сущности?</label><input id="p_fields" placeholder="Например: requestId:string|required|unique"><div class="fieldtip">Отметьте required, unique, indexed и sensitive.</div></div>
 </div>
 <p><button type="button" class="btn ghost" data-action="suggest-basics">подставить безопасный минимум</button></p>
</section>

<section class="card" id="chain-builder"><div class="section-head"><div><h2>3. Соберите гибкую цепочку процесса</h2><p class="hint">Компоненты можно добавлять, удалять, копировать, вставлять до/после, двигать кнопками и перетаскивать мышью на десктопе.</p></div><div class="builder-actions"><button type="button" class="btn ghost" data-action="safe-all">безопасные настройки всем шагам</button></div></div>
 <div class="builder-layout">
  <aside class="component-palette"><h3>Быстро добавить типовой шаг</h3><div class="palette-grid">
   <button type="button" class="palette-btn" data-action="template" data-template="rest"><b>+ REST-вызов</b><small>Синхронный API, timeout, retry, fallback.</small></button>
   <button type="button" class="palette-btn" data-action="template" data-template="kafka"><b>+ Kafka-событие</b><small>Асинхронное событие, DLQ, replay, Inbox.</small></button>
   <button type="button" class="palette-btn" data-action="template" data-template="db"><b>+ запись в БД</b><small>Транзакция, unique key, optimistic locking.</small></button>
   <button type="button" class="palette-btn" data-action="template" data-template="webhook"><b>+ Webhook / callback</b><small>Подпись, timestamp, дедупликация.</small></button>
   <button type="button" class="palette-btn" data-action="template" data-template="batch"><b>+ Batch / файл</b><small>batchId, checksum, quarantine, reprocess.</small></button>
   <button type="button" class="palette-btn" data-action="template" data-template="cdc"><b>+ CDC</b><small>LSN/offset, watermark, replay/resync.</small></button>
   <button type="button" class="palette-btn" data-action="template" data-template="manual"><b>+ Ручной шаг</b><small>Ручной разбор, runbook, оператор.</small></button>
   <button type="button" class="palette-btn" data-action="template" data-template="validation"><b>+ Проверка / валидация</b><small>Бизнес-правила перед изменением состояния.</small></button>
  </div><h3>Добавить участника</h3><div class="palette-grid"><button type="button" class="palette-btn" data-action="add-system" data-system-kind="internal">+ Внутренний сервис</button><button type="button" class="palette-btn" data-action="add-system" data-system-kind="external">+ Внешняя система</button><button type="button" class="palette-btn" data-action="add-system" data-system-kind="broker">+ Kafka / брокер</button><button type="button" class="palette-btn" data-action="add-system" data-system-kind="db">+ База данных</button><button type="button" class="palette-btn" data-action="add-system" data-system-kind="analytics">+ DWH / аналитика</button><button type="button" class="palette-btn" data-action="add-system" data-system-kind="legacy">+ Legacy</button></div></aside>
  <main class="chain-workspace"><h3>Участники процесса</h3><div id="systemsCards" class="systems-grid"></div><datalist id="syslist"></datalist><table id="systems" class="legacy-store"><tbody></tbody></table><h3>Цепочка компонентов</h3><div id="chainList" class="chain-list"></div><table id="steps" class="legacy-store"><tbody></tbody></table></main>
  <aside class="chain-preview"><h3>Карта процесса</h3><div id="processMap" class="process-map"></div><h3 id="readiness">Готовность</h3><div id="readinessPanel"></div><h3>Краткая сводка ввода</h3><div id="reviewBox" class="reviewbox"></div></aside>
 </div>
</section>

<div id="errors"></div>
<div class="sticky-submit"><div><b>Запуск разбора</b><div class="hint" id="submitHint">Проверьте готовность процесса.</div></div><button type="button" class="btn" data-action="submit">Проверить архитектуру</button></div>
<script>{FORM_JS}</script>"""
    return page(f'Интеграционный проектировщик v{APP_VERSION}', body)




def _inv_plain(inv):
    title = inv.get('title') or 'Инвариант'
    question = inv.get('question') or ''
    return f'{title}. Главная проверка: {question}'


def _inv_prefix(inv):
    return str(inv.get('code') or '').split('-')[0].upper()


def _inv_term_hint(inv):
    """Мини-расшифровка терминов, которые часто пугают новичка."""
    text = ' '.join(str(inv.get(k, '')) for k in ('title', 'question', 'why', 'how', 'area')).lower()
    hints = []
    if any(x in text for x in ['scope', 'област', 'уникальн']):
        hints.append('Область уникальности — это ответ на вопрос «где именно этот id не должен повторяться»: во всей системе, внутри типа операции, внутри провайдера, внутри tenant или внутри целевой системы.')
    if any(x in text for x in ['idempotency', 'идемпот']):
        hints.append('Идемпотентность означает, что повтор того же запроса или события не создаёт второй документ, платёж, заявку или статус.')
    if 'dlq' in text:
        hints.append('DLQ — это отдельное место для сообщений, которые не удалось обработать автоматически; после исправления ошибки их нужно уметь безопасно переиграть.')
    if 'replay' in text or 'переигр' in text:
        hints.append('Replay — это повторная обработка уже полученного сообщения или операции после исправления причины ошибки.')
    if 'outbox' in text:
        hints.append('Outbox — это способ сначала надёжно записать событие рядом с бизнес-данными в БД, а потом безопасно опубликовать его в брокер.')
    if 'inbox' in text:
        hints.append('Inbox — это таблица или механизм на стороне получателя, который запоминает уже обработанные события и не даёт обработать дубль второй раз.')
    if 'correlation' in text or 'trace' in text:
        hints.append('CorrelationId или traceId нужен не для уникальности операции, а чтобы найти всю цепочку вызовов и событий при разборе инцидента.')
    if 'backpressure' in text:
        hints.append('Backpressure — это управляемое замедление обработки, чтобы система не умерла под пиком нагрузки.')
    if 'cutover' in text:
        hints.append('Cutover — это момент переключения со старого процесса на новый; для него нужны критерии успеха и план отката.')
    return ' '.join(hints)


def _inv_simple_core(inv):
    """Короткое объяснение без канцелярита: что именно нужно не забыть."""
    prefix = _inv_prefix(inv)
    question = (inv.get('question') or '').rstrip('?.')
    title = (inv.get('title') or '').rstrip('.')
    starters = {
        'BIZ': 'Сначала надо договориться о смысле процесса, а уже потом выбирать Kafka, REST, БД или очереди.',
        'ID': 'Главная мысль: Любой id кажется уникальным, пока не появляется второй тип операции, другая целевая система, другой провайдер или tenant. Поэтому id сам по себе почти никогда не бывает «просто уникальным»; нужно понять, внутри какой области он уникален.',
        'CON': 'Контракт — это не просто JSON-пример, а договор между системами о полях, ошибках, версиях и совместимости.',
        'SCN': 'Процесс нельзя описывать только happy path: обязательно нужны альтернативы, ошибки, зависания и финальные состояния.',
        'DAT': 'Данные должны меняться предсказуемо: один владелец записи, понятная транзакция, защита от дублей и история изменений.',
        'ASY': 'В асинхронной обработке сообщение может прийти дважды, опоздать, прийти не по порядку или упасть в ошибку — это нормальные сценарии, а не исключения.',
        'API': 'В синхронном вызове одна система ждёт другую, поэтому время ожидания, ошибки и деградация должны быть жёстко ограничены.',
        'EXT': 'Внешняя система вам не подчиняется: она может тормозить, вернуть 429/5xx, прислать дубль callback или не дать однозначный результат.',
        'PERF': 'Производительность надо проверять не на среднем happy path, а на пиках, лагах, лимитах зависимостей и росте данных.',
        'SEC': 'Безопасность — это не только авторизация: ПДн, секреты, DLQ, логи, дампы, replay и ручные инструменты тоже должны быть защищены.',
        'OBS': 'Если в production что-то сломалось, команда должна быстро найти цепочку, понять статус и выполнить понятный runbook.',
        'CMP': 'Для денег, регуляторики и юридически значимых действий мало “сделали”: нужно уметь доказать кто, когда, почему и что изменил.',
        'MIG': 'Релиз и миграция должны быть обратимыми: нужно понимать, как переключаемся, что с незавершёнными процессами и как откатываемся.',
        'DWH': 'Аналитика и витрины не должны ломать основной процесс, а данные должны быть полными, проверяемыми и пересобираемыми.',
        'TST': 'Любой важный риск должен превратиться в конкретный тест или production-gate, иначе он останется красивой фразой в отчёте.',
    }
    first = starters.get(prefix, 'Этот пункт нужен, чтобы не пропустить важную проверку до разработки и релиза.')
    return f'{first} В этом инварианте надо проверить: {question}. Если сказать совсем коротко: {title.lower()}.'


def _inv_deep_description(inv):
    """Понятное, но не обеднённое описание инварианта."""
    why = inv.get('why') or ''
    how = inv.get('how') or ''
    hint = _inv_term_hint(inv)
    parts = [_inv_simple_core(inv)]
    if why:
        parts.append(f'Почему это важно: {why}')
    if how:
        parts.append(f'Что нужно сделать: {how}')
    if hint:
        parts.append(f'Расшифровка терминов: {hint}')
    return ' '.join(parts)


def _inv_bad_good(inv):
    prefix = _inv_prefix(inv)
    bad_good = {
        'BIZ': ('Плохо: команда описала набор вызовов, но не знает, какой статус считается финальным и кто владелец результата.', 'Хорошо: есть цель процесса, финальный результат, владелец, обязательные шаги и понятные правила ручного разбора.'),
        'ID': ('Плохо: поиск, дедупликация или replay идут только по requestId/operUid, хотя тот же id может встретиться в другом типе операции или целевой системе.', 'Хорошо: во всех местах используется один составной ключ, например requestId + operationType + targetSystem + tenantId.'),
        'CON': ('Плохо: есть пример JSON, но не описаны required-поля, ошибки, версии, enum и совместимость.', 'Хорошо: есть OpenAPI/AsyncAPI/схема, правила версионирования и contract tests для успеха, дубля, ошибки и новой версии.'),
        'SCN': ('Плохо: описан только основной путь, а зависание, отказ партнёра, отмена, дубль и ручное исправление не разобраны.', 'Хорошо: для каждого важного отклонения есть статус, действие системы, владелец и критерий завершения.'),
        'DAT': ('Плохо: несколько сервисов пишут одну сущность, БД и событие обновляются отдельно, а повтор может создать дубль.', 'Хорошо: есть system of record, транзакционная граница, Outbox/Inbox, уникальные индексы и правила конкурентного обновления.'),
        'ASY': ('Плохо: consumer просто читает сообщение и пишет в БД, но не описаны дубли, DLQ, replay, offset/ack и out-of-order.', 'Хорошо: обработка повторяемая, дедуплицируется, poison message уходит в DLQ, replay безопасен, offset коммитится после успешной записи.'),
        'API': ('Плохо: цепочка REST-вызовов ждёт все внешние системы и суммарно превышает SLA.', 'Хорошо: критический путь короткий, timeout ограничен, тяжёлый хвост вынесен в async, клиент получает trackingId или понятный fallback.'),
        'EXT': ('Плохо: отказ провайдера считается редкостью и не описан как штатный сценарий.', 'Хорошо: есть timeout, circuit breaker, rate limit strategy, status inquiry, дедупликация callback и деградация.'),
        'PERF': ('Плохо: проверили 100 событий на тестовом контуре и решили, что production выдержит пик.', 'Хорошо: рассчитаны RPS, p95/p99, partitions, consumer lag, индексы, rate limits, backpressure и проведены load/stress/soak-тесты.'),
        'SEC': ('Плохо: ПДн, токены или payload событий попадают в логи, DLQ и витрины без маскирования и retention.', 'Хорошо: данные минимизированы, секреты не логируются, доступ ограничен, retention описан, replay защищён.'),
        'OBS': ('Плохо: при инциденте команда ищет руками по разным логам и не понимает, где зависла операция.', 'Хорошо: по одному correlationId видна вся цепочка, есть метрики, алерты, дашборд, владелец и runbook.'),
        'CMP': ('Плохо: операция изменилась, но нельзя доказать автора, время, причину и исходные данные.', 'Хорошо: есть audit trail, ledger/status history, сверки, причины ручных исправлений и неизменяемый журнал.'),
        'MIG': ('Плохо: включили новый поток и надеются, что откатится простым rollback кода.', 'Хорошо: есть dual-run/shadow, cutover checklist, обработка in-flight, совместимость схем и проверенный rollback.'),
        'DWH': ('Плохо: витрина синхронно читает production-БД или отчёт строится без контроля полноты.', 'Хорошо: данные уходят через CDC/ETL вне core-flow, есть watermark, lineage, freshness, сверка и backfill.'),
        'TST': ('Плохо: тест есть только на happy path.', 'Хорошо: есть тест на дубль, out-of-order, timeout, DLQ/replay, контракт, rollback, security-negative и нагрузку.'),
    }
    bad, good = bad_good.get(prefix, ('Плохо: пункт остался как устная договорённость и не попал в контракт, DDL, ADR, тест или DoD.', 'Хорошо: решение зафиксировано в артефакте и проверяется до релиза.'))
    return f'{bad} {good}'


def _inv_steps_to_apply(inv):
    prefix = _inv_prefix(inv)
    common = {
        'BIZ': '1) Назовите бизнес-результат. 2) Укажите владельца результата. 3) Разделите обязательные и необязательные шаги. 4) Опишите финальные статусы и ручной разбор.',
        'ID': '1) Выпишите все id. 2) Для каждого id укажите область уникальности. 3) Сравните lookup, UNIQUE-индекс, idempotency key, Inbox/Outbox и replay. 4) Исправьте места, где ключ неполный.',
        'CON': '1) Зафиксируйте схему. 2) Отметьте required/optional поля. 3) Опишите ошибки и enum. 4) Проверьте backward/forward compatibility. 5) Добавьте contract tests.',
        'SCN': '1) Опишите happy path. 2) Для каждого шага добавьте отказную ветку. 3) Добавьте альтернативы и отмену. 4) Укажите финальные статусы. 5) Добавьте критерии приёмки.',
        'DAT': '1) Найдите владельца сущности. 2) Опишите границы транзакций. 3) Добавьте уникальные индексы. 4) Проверьте повторы и конкурентные обновления. 5) Зафиксируйте аудит/историю.',
        'ASY': '1) Опишите delivery semantics. 2) Добавьте idempotency/Inbox. 3) Опишите retry, DLQ и replay. 4) Определите partition/ordering. 5) Настройте lag/DLQ-алерты.',
        'API': '1) Посчитайте timeout критического пути. 2) Ограничьте retry. 3) Добавьте error contract. 4) Настройте circuit breaker/fallback. 5) Сверьте с SLA.',
        'EXT': '1) Узнайте лимиты и SLA провайдера. 2) Опишите timeout/429/5xx. 3) Добавьте idempotency и status inquiry. 4) Проверьте callback signature и duplicate callback. 5) Опишите деградацию.',
        'PERF': '1) Укажите средний и пиковый RPS. 2) Найдите узкие места. 3) Проверьте индексы/партиции/lag. 4) Добавьте backpressure. 5) Проведите load/stress/soak.',
        'SEC': '1) Найдите ПДн/секреты. 2) Проверьте логи, DLQ, outbox и витрины. 3) Ограничьте доступ. 4) Опишите retention. 5) Добавьте security-negative tests.',
        'OBS': '1) Проведите correlationId через все шаги. 2) Добавьте метрики и алерты. 3) Назначьте владельца. 4) Напишите runbook. 5) Проверьте разбор одного тестового инцидента.',
        'CMP': '1) Определите юридически значимые действия. 2) Запишите audit trail. 3) Добавьте сверки. 4) Опишите ручные исправления. 5) Проверьте хранение доказательств.',
        'MIG': '1) Опишите старый и новый путь. 2) Запустите dual-run/shadow. 3) Опишите cutover. 4) Решите судьбу in-flight процессов. 5) Проверьте rollback.',
        'DWH': '1) Уберите DWH из core-flow. 2) Опишите CDC/ETL. 3) Добавьте watermark и сверки. 4) Укажите freshness. 5) Подготовьте backfill.',
        'TST': '1) Возьмите риск из инварианта. 2) Превратите его в тест-кейс. 3) Добавьте проверку в DoD. 4) Прогоните happy path и отказные ветки. 5) Зафиксируйте ожидаемый результат.',
    }
    return common.get(prefix, '1) Ответьте на вопрос карточки. 2) Зафиксируйте решение в проектном артефакте. 3) Добавьте проверку в DoD или тест. 4) Назначьте владельца.')


def _inv_normal_state(inv):
    prefix = _inv_prefix(inv)
    if prefix == 'BIZ':
        return 'Нормальное состояние: понятны бизнес-цель, финальный результат, владелец процесса, обязательные и необязательные шаги, финальные статусы и правила ручного разбора.'
    if prefix == 'ID':
        return 'Нормальное состояние: для каждого id написано, где он уникален. Один и тот же набор полей используется в SELECT, UPDATE, UPSERT, UNIQUE-индексе, idempotency key, Inbox/Outbox и replay. Например, не просто requestId, а requestId + operationType + targetSystem + tenantId.'
    if prefix == 'CON':
        return 'Нормальное состояние: контракт описан в OpenAPI/AsyncAPI или другой явной схеме, а не только примером. В нём есть версии, обязательные поля, enum, формат ошибок и правила совместимости. Все важные ветки проверяются contract tests.'
    if prefix == 'SCN':
        return 'Нормальное состояние: кроме happy path описаны альтернативные ветки, ошибки, отмена, зависания, финальные статусы и владелец ручного разбора.'
    if prefix == 'DAT':
        return 'Нормальное состояние: понятно, кто владеет сущностью, кто имеет право писать, где граница транзакции, как защищаемся от дублей, гонок и фантомных событий.'
    if prefix == 'ASY':
        return 'Нормальное состояние: повтор сообщения безопасен, дубль не создаёт вторую бизнес-операцию, DLQ и replay описаны, offset/ack коммитится в правильный момент, порядок событий учтён.'
    if prefix == 'API':
        return 'Нормальное состояние: каждый синхронный вызов имеет короткий timeout, ограниченный retry, понятный ответ об ошибке, circuit breaker/fallback и укладывается в общий SLA.'
    if prefix == 'EXT':
        return 'Нормальное состояние: внешний отказ не ломает весь процесс. Есть лимиты, timeout, circuit breaker, status inquiry, дедупликация callback и понятный сценарий деградации.'
    if prefix == 'PERF':
        return 'Нормальное состояние: рассчитаны средняя и пиковая нагрузка, consumer lag, rate limits, индексы, рост таблиц, backpressure и деградация. Это подтверждено нагрузочными тестами.'
    if prefix == 'SEC':
        return 'Нормальное состояние: ПДн и секреты минимизированы, маскируются и не попадают в логи/DLQ/outbox/витрины без правил доступа и retention.'
    if prefix == 'OBS':
        return 'Нормальное состояние: по одному correlationId можно восстановить путь операции через все системы, увидеть статус, ошибки, лаги, DLQ, владельца алерта и runbook.'
    if prefix == 'CMP':
        return 'Нормальное состояние: юридически значимые изменения пишутся в неизменяемую историю, ручные исправления имеют автора/причину/время, а результат можно сверить с источником.'
    if prefix == 'MIG':
        return 'Нормальное состояние: есть план переключения, dual-run или shadow mode, обработка незавершённых процессов, совместимость версий и проверенный откат.'
    if prefix == 'DWH':
        return 'Нормальное состояние: аналитика получает данные вне основного клиентского процесса, полнота контролируется, freshness известна, lineage есть, backfill возможен.'
    if prefix == 'TST':
        return 'Нормальное состояние: для инварианта есть конкретный тест или production-gate. Тест покрывает не только успех, но и дубли, отказы, rollback, безопасность или нагрузку.'
    return 'Нормальное состояние: решение явно отвечает на вопрос карточки, зафиксировано в контракте, ADR, DDL, тесте или DoD и имеет владельца.'


def _inv_review_questions(inv):
    prefix = _inv_prefix(inv)
    base = inv.get('question') or 'Что нужно проверить по этому инварианту?'
    extra = {
        'BIZ': 'Какой финальный результат? Кто владелец? Что видит клиент или система-потребитель? Какие шаги можно выполнить позже?',
        'ID': 'Где именно уникален id? Совпадают ли поля SELECT, UPDATE, UPSERT, UNIQUE, idempotency, Inbox, Outbox и replay?',
        'CON': 'Проверены ли успех, ошибка, дубль, новая версия, неизвестное enum-значение и отсутствие обязательного поля?',
        'SCN': 'Что происходит при отказе каждого шага, зависании, отмене, повторе, частичном успехе и ручном исправлении?',
        'DAT': 'Кто единственный писатель? Где атомарность? Что будет при двух параллельных запросах и повторной доставке?',
        'ASY': 'Когда коммитится offset/ack? Где DLQ? Кто делает replay? Как обрабатываются дубль, stale event и out-of-order?',
        'API': 'Сходится ли сумма timeout с SLA? Что при 429/5xx/timeout? Есть ли ограниченный retry, circuit breaker и fallback?',
        'EXT': 'Какие лимиты провайдера? Что при дубле callback, невалидной подписи, неизвестном результате и недоступности?',
        'PERF': 'Какой peak RPS, p95/p99, limit зависимости, lag, размер таблиц, индексы и план деградации?',
        'SEC': 'Попадают ли ПДн/секреты в логи, DLQ, outbox, дампы, витрины, ошибочные ответы или replay-инструменты?',
        'OBS': 'Можно ли по одному id расследовать инцидент? Какие метрики/алерты сработают? Кто владелец? Есть ли runbook?',
        'CMP': 'Можно ли доказать факт операции, автора, время, причину исправления и источник данных для отчёта?',
        'MIG': 'Как переключаем трафик? Что с in-flight? Как сравниваем старый и новый путь? Как откатываемся?',
        'DWH': 'Как доказать полноту выгрузки, freshness, lineage и возможность пересобрать период?',
        'TST': 'Какой конкретный тест доказывает, что инвариант соблюдён? Где он в QA/DoD?',
    }.get(prefix, 'Где это зафиксировано и кто отвечает за проверку перед релизом?')
    return f'Главный вопрос: {base} Дополнительные вопросы: {extra}'


def _inv_example(inv):
    examples = inv.get('examples') or []
    if examples:
        return '; '.join(str(x) for x in examples)
    code = (inv.get('code') or '').upper()
    area = (inv.get('area') or '').lower()
    title = (inv.get('title') or '').lower()
    if code.startswith('ID-') or 'ключ' in area or 'идентификатор' in title:
        return 'Ошибка: универсальный адаптер ищет запись только по requestId. В процессе есть разные operationType и targetSystem, поэтому запись системы A может пересечься с записью системы B. Правильно: искать и дедуплицировать по requestId + operationType + targetSystem.'
    if code.startswith('CON-') or 'контракт' in area:
        return 'Ошибка: в успешном ответе поле statusReason есть, а в ветке “дубль” его забыли вернуть, хотя по контракту поле обязательное. Правильно: contract test должен проверить все ветки ответа.'
    if code.startswith('EVT-') or 'событ' in area:
        return 'Ошибка: событие пришло без eventVersion и correlationId. Потребитель не может безопасно обработать новую версию и расследовать цепочку. Правильно: использовать event envelope.'
    if code.startswith('OBS-') or 'наблюдаем' in area:
        return 'Ошибка: заявка зависла, но в логах разных систем нет общего correlationId, алерта и владельца. Поддержка ищет причину вручную. Правильно: сквозной correlationId, метрики, алерты, дашборд и runbook.'
    if code.startswith('CMP-') or 'комплаенс' in area or 'аудит' in area:
        return 'Ошибка: статус финансовой операции изменили вручную, но не зафиксировали автора, причину и исходные данные. Правильно: audit trail, причина исправления, автор, время и сверка с источником.'
    if code.startswith('TST-') or 'тест' in area:
        return 'Ошибка: проверили только успешный путь. В production пришёл дубль, out-of-order событие или ошибка контракта. Правильно: добавить отдельный тест на этот отказный сценарий.'
    if 'retry' in title or 'dlq' in title or 'replay' in title or 'надёж' in area:
        return 'Ошибка: consumer упал после записи в БД, Kafka прислала сообщение повторно, и создалась вторая бизнес-запись. Правильно: сначала проверить idempotency/Inbox, потом писать данные, затем коммитить offset.'
    if 'статус' in area or 'статус' in title:
        return 'Ошибка: заявка зависла между SENT и COMPLETED, но нет статуса ERROR/NEEDS_MANUAL_REVIEW и неясно, кто должен разбирать зависание.'
    if 'безопас' in area or 'пдн' in title or 'sensitive' in title:
        return 'Ошибка: паспортные данные попали в лог, DLQ или outbox без маскирования и срока хранения. Правильно: минимизировать payload, маскировать ПДн и ограничить доступ.'
    if 'dwh' in area or 'cdc' in title or 'витрин' in title:
        return 'Ошибка: аналитическая витрина синхронно читает production-БД и влияет на клиентский сценарий. Правильно: CDC/ETL вне core-flow и сверка полноты.'
    if 'миграц' in area or 'legacy' in title or 'rollback' in title:
        return 'Ошибка: новая схема данных включена без rollback-плана. При откате старый сервис не понимает новые поля или статусы.'
    if 'нагруз' in area or 'consumer' in title or 'backpressure' in title:
        return 'Ошибка: пик входящих событий превышает способность consumer group, растёт lag, а backpressure и алерты не описаны.'
    if 'внешн' in area or 'provider' in title or 'timeout' in title:
        return 'Ошибка: внешний сервис отвечает 10 секунд, а клиентский SLA — 1 секунда. Правильно: ограничить timeout, включить circuit breaker и вернуть trackingId/деградацию.'
    return 'Ошибка: команда устно договорилась “потом разберёмся”, но не добавила проверку в контракт, DDL, ADR, тест или Definition of Done.'


def _inv_stage(inv):
    prefix = _inv_prefix(inv)
    area = (inv.get('area') or '').lower()
    scope = (inv.get('scope') or '').lower()
    if prefix == 'BIZ':
        return 'Сбор требований и предпроект: до выбора протоколов, топиков, БД и контрактов. Повторить перед согласованием сценария.'
    if prefix == 'ID':
        return 'Проектирование данных и контрактов: до DDL, API/Event-схем, Inbox/Outbox и replay. Повторить при любом изменении ключей.'
    if prefix == 'CON':
        return 'Проектирование API/Event/File-контракта: до разработки. Обязательно проверить на контрактном ревью и в contract tests.'
    if prefix == 'SCN':
        return 'Проектирование сценария: после happy path и до постановки задач в разработку. Потом перенести в QA-сценарии.'
    if prefix == 'DAT':
        return 'Проектирование хранения и записи: до DDL, миграций, разработки записи и публикации событий.'
    if prefix == 'ASY':
        return 'Проектирование асинхронной обработки: до создания топиков, consumer group, retry, DLQ и replay-процедур.'
    if prefix == 'API':
        return 'Проектирование синхронного взаимодействия: до утверждения SLA, timeout, retry и клиентского контракта ошибок.'
    if prefix == 'EXT':
        return 'Интеграция с внешней системой: до подключения провайдера и до отказных/нагрузочных тестов.'
    if prefix == 'DWH':
        return 'Проектирование аналитического контура: до выбора CDC/ETL, витрин, retention и правил сверки с источником.'
    if prefix == 'MIG':
        return 'План внедрения и миграции: до релиза, cutover, dual-run и rollback-плана.'
    if prefix == 'SEC' or 'безопас' in area or scope == 'security':
        return 'Security/Data review: до вывода данных в логи, DLQ, outbox, витрины и внешние интеграции.'
    if prefix == 'PERF':
        return 'Capacity planning: до согласования SLA и перед load/stress/soak-тестированием.'
    if prefix == 'OBS':
        return 'Проектирование эксплуатации: до запуска в тестовый контур и до настройки алертов/дашбордов.'
    if prefix == 'CMP':
        return 'Комплаенс и аудит: до согласования регуляторного или финансового процесса и перед production gate.'
    if prefix == 'TST':
        return 'План тестирования: до разработки автотестов и перед release readiness.'
    return 'Архитектурное ревью: проверить до постановки в разработку и повторить перед выпуском.'


def _inv_when(inv):
    prefix = _inv_prefix(inv)
    title = (inv.get('title') or '').lower()
    area = (inv.get('area') or '').lower()
    if prefix == 'ID':
        return 'Всегда, когда id используется для поиска, обновления, дедупликации, идемпотентности, replay или связи записей между системами.'
    if prefix == 'CON':
        return 'Всегда, когда одна система отдаёт другой API, событие, файл, webhook или batch-формат.'
    if prefix == 'SCN':
        return 'Для любого процесса длиннее одного шага, особенно если есть статусы, ожидание внешней системы, ручной разбор или клиентский результат.'
    if prefix == 'DAT':
        return 'Когда шаг пишет бизнес-сущность, меняет статус, создаёт операцию, публикует событие после записи или допускает параллельные обновления.'
    if prefix == 'ASY':
        return 'Для Kafka, очередей, webhook/callback, CDC, файловой загрузки и любой обработки, где результат появляется позже запроса.'
    if prefix == 'API':
        return 'Для REST, gRPC, SOAP и прямых синхронных вызовов, где вызывающая система ждёт ответ.'
    if prefix == 'EXT':
        return 'При любом провайдере или системе вне вашего контроля: банк, УК, БКИ, PSP, KYC, логистика, гос/регуляторный контур.'
    if prefix == 'DWH':
        return 'Когда данные уходят в DWH, витрины, BI, отчётность, ML, CDC/ETL или читаются аналитическим контуром.'
    if prefix == 'MIG':
        return 'При замене legacy, параллельном запуске старого и нового потока, изменении схемы, cutover или rollback.'
    if prefix == 'SEC':
        return 'При ПДн, финансовых данных, секретах, токенах, webhook-подписях, внешних каналах, логах и DLQ.'
    if prefix == 'PERF':
        return 'Когда есть SLA, RPS, пики нагрузки, consumer lag, rate limits, большие таблицы, массовая обработка или highload.'
    if prefix == 'OBS':
        return 'Для распределённых цепочек, асинхронных потоков, внешних вызовов и процессов, которые должна сопровождать поддержка.'
    if prefix == 'CMP':
        return 'Для денег, юридически значимых действий, регуляторной отчётности, аудита и процессов с ручным согласованием.'
    if prefix == 'TST':
        return 'При подготовке DoD, QA-чек-листа, контрактных, интеграционных, отказных и регрессионных тестов.'
    if 'файл' in area or 'batch' in title:
        return 'Для файлового обмена, пакетной обработки и повторной загрузки больших наборов данных.'
    return 'Если условие из карточки может встретиться в процессе или влияет на данные, SLA, восстановление, безопасность или эксплуатацию.'


def _inv_consequence(inv):
    prefix = _inv_prefix(inv)
    if prefix == 'ID':
        return 'Система может найти или обновить чужую запись, ошибочно принять корректное событие за дубль, создать дубль при replay или перезаписать операцию другой целевой системы.'
    if prefix == 'CON':
        return 'Потребитель сломается на новой версии, редкая ветка вернёт неполный ответ, обязательное поле пропадёт в ошибке или дубле, а дефект всплывёт на интеграции или в production.'
    if prefix == 'SCN':
        return 'Процесс зависнет в промежуточном статусе, поддержка не поймёт владельца проблемы, клиент увидит неопределённый результат, а команда начнёт чинить вручную без правил.'
    if prefix == 'DAT':
        return 'Появятся рассинхрон, lost update, двойная запись, фантомное событие, конфликт владельцев данных или невозможность доказать корректное состояние.'
    if prefix == 'ASY':
        return 'Сообщение потеряется, будет бесконечно ретраиться, попадёт в DLQ без процедуры восстановления, обработается не по порядку или создаст дубль.'
    if prefix == 'API':
        return 'Один медленный вызов потянет задержку по всей цепочке, исчерпает пул потоков, нарушит SLA и может вызвать каскадный отказ.'
    if prefix == 'EXT':
        return 'Отказ или лимит внешней системы станет отказом вашего процесса: появятся 429, timeout, дубли callback или неизвестный результат без понятной деградации.'
    if prefix == 'DWH':
        return 'Аналитика начнёт влиять на core-flow, витрины разойдутся с источником, отчётность будет неполной или устаревшей, а период нельзя будет пересобрать.'
    if prefix == 'MIG':
        return 'Релиз нельзя будет безопасно откатить, старый и новый потоки разойдутся, in-flight процессы потеряются, данные новой схемы окажутся несовместимы со старой системой.'
    if prefix == 'SEC':
        return 'ПДн или секреты попадут в логи, DLQ, outbox или витрины; появится риск утечки, replay-атаки, неверного доступа или нарушения retention.'
    if prefix == 'PERF':
        return 'На пике вырастет latency, consumer lag, очередь, размер таблиц или число 429; система начнёт деградировать именно в момент максимальной нагрузки.'
    if prefix == 'OBS':
        return 'Инцидент нельзя будет быстро расследовать: не будет сквозного id, метрик, алертов, владельца или runbook для восстановления.'
    if prefix == 'CMP':
        return 'Не получится доказать юридически значимый шаг, провести сверку, объяснить ручное исправление или восстановить аудиторскую картину процесса.'
    if prefix == 'TST':
        return 'Критичный сценарий не попадёт в тесты: дубли, out-of-order, ошибка контракта, rollback, security-negative или нагрузочный дефект всплывут после релиза.'
    return 'Проблема проявится не на happy path, а при отказе, повторе, ручном исправлении, миграции или production-инциденте.'


def _inv_reference_case(inv):
    prefix = _inv_prefix(inv)
    if prefix == 'ID':
        return 'Универсальный адаптер отправляет запросы в системы A и B. Везде используется один ключ: requestId + operationType + targetSystem + tenantId. Именно этот ключ стоит в DDL, SELECT, UPDATE, Inbox, Outbox и replay.'
    if prefix == 'CON':
        return 'Для REST API или Kafka-события есть схема, версия, required-поля и contract tests. Тесты проверяют успешный ответ, дубль, ошибку, неизвестное enum-значение и новую версию.'
    if prefix == 'SCN':
        return 'Для заявки описаны CREATED → SENT → PROCESSING → COMPLETED/REJECTED/NEEDS_MANUAL_REVIEW. Для каждого статуса понятно, кто его выставляет и что делать при зависании.'
    if prefix == 'DAT':
        return 'Сервис-владелец пишет в свою БД и публикует событие через Transactional Outbox. Потребитель применяет Inbox и optimistic locking при обновлении проекции.'
    if prefix == 'ASY':
        return 'Consumer читает Kafka at-least-once: проверяет Inbox/idempotency key, пишет данные, коммитит offset после успеха, отправляет poison message в DLQ и имеет replay-runbook.'
    if prefix == 'API':
        return 'Клиентский API отвечает быстро: тяжёлые проверки уходят в фон с trackingId, а синхронные вызовы имеют timeout, retry budget, circuit breaker и fallback.'
    if prefix == 'EXT':
        return 'Интеграция с PSP учитывает rate limit, idempotency key, подпись callback, повторные уведомления, timeout, circuit breaker и деградацию при недоступности PSP.'
    if prefix == 'DWH':
        return 'Данные в витрину попадают через CDC/ETL вне клиентского core-flow. Есть watermark, контрольные суммы, lineage и сверка количества/сумм с источником истины.'
    if prefix == 'MIG':
        return 'Новый поток запускается в dual-run со старым, результаты сравниваются, cutover идёт по чек-листу, rollback проверен заранее.'
    if prefix == 'SEC':
        return 'Событие содержит только минимально нужные поля. ПДн маскируются в логах, DLQ и отчётах; доступ к replay и ручному исправлению ограничен ролями.'
    if prefix == 'PERF':
        return 'Для consumer group рассчитаны partitions, throughput, max lag, backpressure и retention. Нагрузочный тест покрывает средний поток, пик, стресс и длительный soak.'
    if prefix == 'OBS':
        return 'Во всех логах и событиях есть correlationId/traceId. Настроены алерты на DLQ, lag, 5xx, timeout, retry storm и зависшие статусы; есть runbook.'
    if prefix == 'CMP':
        return 'Для финансовой операции есть audit trail, ledger/status_history, сверка с внешней системой и журнал ручных исправлений с причиной, автором и временем.'
    if prefix == 'TST':
        return 'QA-план содержит контрактные тесты, duplicate delivery, out-of-order, replay из DLQ, отказ внешней системы, rollback, security-negative и нагрузочный прогон.'
    return _inv_example(inv)


def _inv_verification(inv):
    prefix = _inv_prefix(inv)
    if prefix == 'ID':
        return 'Возьмите один id и пройдите его путь: входной контракт → поиск → запись → уникальный индекс → дедупликация → replay. Если где-то используется другой набор полей, есть риск.'
    if prefix == 'CON':
        return 'Откройте контракт и тесты. Для каждого required-поля, enum, ошибки и версии должен быть автоматический тест или явный production-gate.'
    if prefix == 'SCN':
        return 'Пройдите процесс как сценарий: основной путь, отказ каждого внешнего шага, дубль, отмена, зависание, ручной разбор. У каждого состояния должен быть следующий допустимый переход.'
    if prefix == 'DAT':
        return 'Проверьте, кто пишет сущность, где транзакция, есть ли UNIQUE/locking, не расходятся ли БД и событие, что будет при двух параллельных запросах.'
    if prefix == 'ASY':
        return 'Сымитируйте повтор сообщения, падение consumer после записи, poison message, replay из DLQ и out-of-order доставку. Бизнес-дублей быть не должно.'
    if prefix == 'API':
        return 'Сложите timeout всех блокирующих шагов, проверьте 429/5xx/timeout, circuit breaker и fallback. Ответ должен укладываться в SLA или уходить в async.'
    if prefix == 'EXT':
        return 'Через sandbox/заглушку провайдера проверьте timeout, 429, дубль callback, невалидную подпись, задержку, недоступность и неизвестный результат.'
    if prefix == 'DWH':
        return 'Сравните источник истины и витрину по количеству, суммам, watermark, freshness и lineage. Проверьте, что период можно пересобрать через backfill.'
    if prefix == 'MIG':
        return 'Проведите пробный cutover и rollback, сравните dual-run, проверьте совместимость старой и новой схемы и обработку in-flight процессов.'
    if prefix == 'SEC':
        return 'Проверьте логи, DLQ, outbox, дампы, витрины, сообщения об ошибке и replay-инструменты: там не должно быть лишних ПДн/секретов и открытого доступа.'
    if prefix == 'PERF':
        return 'Запустите load/stress/soak, измерьте p95/p99, lag, saturation, размер таблиц, rate limits и поведение при деградации.'
    if prefix == 'OBS':
        return 'Возьмите один correlationId и восстановите путь через все системы, логи, метрики, алерты и дашборды. Должно быть понятно, кто чинит проблему.'
    if prefix == 'CMP':
        return 'По одной операции проверьте доказательность: кто, когда, почему изменил данные, какой был исходный источник и как результат сверяется.'
    if prefix == 'TST':
        return 'Убедитесь, что у инварианта есть конкретный тест-кейс, проверка в DoD или production-gate. Без этого пункт считается незакрытым.'
    return 'Проверьте пункт на архитектурном ревью и добавьте его в DoD, контракт или тест-кейс.'

def invariant_reference_page():
    areas = sorted({str(i.get('area') or 'Другое') for i in INVARIANT_CATALOG})
    options = ''.join(f'<option value="{escape(a.lower())}">{escape(a)}</option>' for a in areas)
    cards = []
    for inv in INVARIANT_CATALOG:
        area = str(inv.get('area') or 'Другое')
        when = _inv_when(inv)
        stage = _inv_stage(inv)
        consequence = _inv_consequence(inv)
        reference_case = _inv_reference_case(inv)
        verification = _inv_verification(inv)
        deep_description = _inv_deep_description(inv)
        normal_state = _inv_normal_state(inv)
        review_questions = _inv_review_questions(inv)
        bad_good = _inv_bad_good(inv)
        steps_to_apply = _inv_steps_to_apply(inv)
        term_hint = _inv_term_hint(inv)
        hay = ' '.join([str(inv.get(k, '')) for k in ('code', 'area', 'title', 'question', 'why', 'how', 'scope')] + [when, stage, consequence, reference_case, verification, deep_description, normal_state, review_questions, bad_good, steps_to_apply, term_hint]).lower()
        example = _inv_example(inv)
        examples = inv.get('examples') or []
        extra_examples = ''
        if examples:
            extra_examples = '<ul>' + ''.join(f'<li>{escape(str(x))}</li>' for x in examples) + '</ul>'
        short = inv.get('question') or deep_description
        cards.append(f'''<details class="refcard" data-area="{escape(area.lower())}" data-search="{escape(hay)}">
 <summary class="ref-summary">
  <div class="ref-summary-top"><span class="refcode">{escape(inv.get('code',''))}</span><span class="refarea">{escape(area)}</span></div>
  <h3>{escape(inv.get('title','Инвариант'))}</h3>
  <p>{escape(short)}</p>
 </summary>
 <div class="ref-content">
  <section class="refbox reflead"><h4>Простыми словами</h4><p>{escape(deep_description)}</p></section>
  <section class="ref-section"><h4>Когда использовать</h4><p>{escape(when)}</p></section>
  <section class="ref-section"><h4>На каком этапе процесса</h4><p>{escape(stage)}</p></section>
  <section class="refbox okbox"><h4>Как выглядит правильное решение</h4><p>{escape(normal_state)}</p></section>
  <section class="ref-section"><h4>Как применить по шагам</h4><p>{escape(steps_to_apply)}</p></section>
  <section class="ref-section"><h4>Что проверить</h4><p>{escape(inv.get('question',''))}</p></section>
  <section class="ref-section"><h4>Почему это важно</h4><p>{escape(inv.get('why',''))}</p></section>
  <section class="ref-section"><h4>Плохо / правильно</h4><p>{escape(bad_good)}</p></section>
  <section class="ref-section"><h4>Вопросы для ревью</h4><p>{escape(review_questions)}</p></section>
  <section class="ref-section"><h4>Как закрыть</h4><p>{escape(inv.get('how',''))}</p></section>
  <section class="ref-section danger"><h4>Последствия, если не соблюдать</h4><p>{escape(consequence)}</p></section>
  <section class="ref-section"><h4>Эталонный кейс</h4><p>{escape(reference_case)}</p></section>
  <section class="ref-section"><h4>Как проверить на практике</h4><p>{escape(verification)}</p></section>
  <section class="ref-section example"><h4>Пример ошибки</h4><p>{escape(example)}</p>{extra_examples}</section>
 </div>
</details>''')
    important_codes = {'ID-001','ID-002','CON-001','CON-002','STAT-001','ERR-001','REL-001','REL-002','OBS-001','MIG-002'}
    important = [i for i in INVARIANT_CATALOG if i.get('code') in important_codes]
    top_cards = ''.join(
        f'<div class="refbox"><b>{escape(i.get("code",""))} · {escape(i.get("title",""))}</b><br>{escape(_inv_example(i))}</div>'
        for i in important
    )
    body = titleblock('СПРАВОЧНИК ИНВАРИАНТОВ · КАРТОЧКИ', active='invariants') + f'''
<section class="hero">
 <h2>Справочник архитектурных инвариантов</h2>
 <p>Текст справочника сохранён по смыслу, но теперь он разбит на раскрывающиеся карточки. Открывайте только нужный пункт, ищите по термину или фильтруйте по области.</p>
 <div class="navlinks"><a class="btn ghost" href="{url_for('/')}">Вернуться в конструктор процесса</a></div>
</section>
<section class="card">
 <h2>Как пользоваться</h2>
 <p>Найдите термин: <b>operUid</b>, <b>retry</b>, <b>DLQ</b>, <b>eventVersion</b>, <b>rollback</b>. Каждая карточка раскрывается и показывает объяснение, этап, правильное состояние, последствия, проверку и пример ошибки.</p>
 <h3>10 инвариантов, которые чаще всего ломают интеграции</h3>
 <div class="top10">{top_cards}</div>
 <div class="refbar">
  <input id="inv_q" placeholder="Поиск по справочнику: ключ, retry, Kafka, ПДн, rollback...">
  <select id="inv_area"><option value="">Все области</option>{options}</select>
 </div>
 <p class="hint" id="inv_count">Показаны все инварианты.</p>
 <div class="refempty" id="inv_empty">По таким условиям ничего не найдено. Попробуйте другой термин или выберите «Все области».</div>
</section>
<section class="card">
 <h2>Список инвариантов</h2>
 <div class="ref-list">{''.join(cards)}</div>
</section>
<script>
function filterInvariants(){{
  const q=(document.getElementById('inv_q').value||'').toLowerCase().trim();
  const area=(document.getElementById('inv_area').value||'').toLowerCase();
  let shown=0,total=0;
  document.querySelectorAll('details.refcard').forEach(card=>{{
    total++;
    const text=(card.dataset.search||card.textContent||'').toLowerCase();
    const okq=!q || text.includes(q);
    const oka=!area || card.dataset.area===area;
    const ok=okq&&oka;
    card.hidden=!ok;
    if(ok) shown++;
  }});
  document.getElementById('inv_count').textContent='Показано: '+shown+' из '+total+'.';
  document.getElementById('inv_empty').style.display=shown?'none':'block';
}}
window.addEventListener('DOMContentLoaded', function(){{
  document.getElementById('inv_q')?.addEventListener('input', filterInvariants);
  document.getElementById('inv_area')?.addEventListener('change', filterInvariants);
  filterInvariants();
}});
</script>'''
    return page(f'Справочник инвариантов v{APP_VERSION}', body)

MERMAID_HEAD = """<script>
window.addEventListener('DOMContentLoaded',function(){
  var s=document.createElement('script');
  s.src='https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js';
  s.onload=function(){mermaid.initialize({startOnLoad:true,theme:'neutral'})};
  s.onerror=function(){document.querySelectorAll('.mermaid').forEach(function(d){
    var p=document.createElement('pre');p.textContent=d.textContent;d.replaceWith(p);})};
  document.head.appendChild(s);});
</script>"""


def section(title, html, open_=False, anchor=''):
    o = ' open' if open_ else ''
    aid = f' id="{escape(anchor)}"' if anchor else ''
    return f'<details class="card"{o}{aid}><summary><h2>{escape(title)}</h2></summary><div class="inside">{html}</div></details>'



def _fix_link(title, text):
    data = ((title or '') + ' ' + (text or '')).lower()
    if any(x in data for x in ('ключ', 'scope', 'идентификатор', 'requestid', 'operuid', 'externalid', 'idempotency')):
        return f'<a class="jumpfix" href="{url_for("/#fix-lookup")}">Открыть поле ключей</a>'
    if any(x in data for x in ('статус', 'финальн')):
        return f'<a class="jumpfix" href="{url_for("/#fix-statuses")}">Открыть поле статусов</a>'
    if any(x in data for x in ('поле', 'контракт', 'event envelope', 'eventid', 'eventversion', 'sensitive')):
        return f'<a class="jumpfix" href="{url_for("/#fix-fields")}">Открыть поле ключевых полей</a>'
    if any(x in data for x in ('огранич', 'компромисс', 'нельзя', 'срок', 'бюджет')):
        return f'<a class="jumpfix" href="{url_for("/#fix-constraints")}">Открыть поле ограничений</a>'
    return f'<a class="jumpfix" href="{url_for("/")}">Вернуться к вводным</a>'

def result_page(rid, res):
    v, m = res['verdict'], res['model']['meta']
    comp = res.get('completeness') or {'summary': 'Полнота вводных не рассчитана.', 'missing': []}
    gates = res.get('quality_gates') or {'readiness': 'не рассчитано', 'gates': [], 'overall': 'warn'}
    checklist = res.get('checklist') or {'items': [], 'counters': {}}
    artifacts = res.get('artifacts') or {}
    finding_groups = res.get('finding_groups') or [
        {**f, 'count': 1, 'affected': [f.get('where', '')],
         'where_summary': f.get('where', ''), 'where': f.get('where', '')}
        for f in (res.get('findings') or [])
    ]
    parts = [titleblock(f'РАЗБОР {rid[:8].upper()}', active='builder')]
    parts.append(f"""<div class="verdict {v['color']}">
 <h2>{escape(v['verdict'])} · {v['score']}/10</h2>
 <p>Готовность к production: {escape(gates.get('readiness','не рассчитано'))}. {escape(comp.get('summary',''))}<br>
 Классы рисков: критичные — {v.get('group_counts',{}).get('critical', v['counts']['critical'])}, высокие — {v.get('group_counts',{}).get('high', v['counts']['high'])}, средние — {v.get('group_counts',{}).get('medium', v['counts']['medium'])}. Всего срабатываний правил: {sum(v['counts'].values())}<br>
 <a href="{url_for('/run/' + rid + '.md')}">скачать полный Markdown-отчёт</a> · <a href="{url_for('/')}">начать новый разбор</a> · <a href="{url_for('/invariants')}">справочник инвариантов</a></p>
</div>""")
    parts.append('<nav class="resultnav" aria-label="Навигация по результату">\n <a href="#main-actions">Главное</a>\n <a href="#checklist">Риски и чек-листы</a>\n <a href="#scenario-base">Сценарий</a>\n <a href="#artifacts">Артефакты</a>\n</nav>')

    action_items = []
    for i in checklist.get('items') or []:
        if i.get('status') == 'fail':
            action_items.append(('Чек-лист', i.get('fix') or i.get('title')))
    for i in comp.get('missing') or []:
        if i.get('priority') == 'high':
            action_items.append(('Уточнить вводные', i.get('question')))
    for f in finding_groups:
        if f.get('severity') == 'critical':
            suffix = f" Затронуто мест: {f.get('count')}." if f.get('count', 1) > 1 else ''
            action_items.append(('Критичный риск', (f.get('fix') or '') + suffix))
    seen, top = set(), []
    for area, text in action_items:
        text = (text or '').strip()
        if text and text not in seen:
            seen.add(text); top.append((area, text))
        if len(top) >= 6:
            break
    if top:
        actions_html = '<div class="actions">' + ''.join(f'<div class="action"><b>{escape(a)}</b><br>{escape(t)}{_fix_link(a, t)}</div>' for a, t in top) + '</div>'
    else:
        actions_html = '<p>Блокирующих первоочередных действий не найдено. Всё равно проверьте контракт, тесты и эксплуатационные требования.</p>'
    parts.append(section('Что сделать в первую очередь', actions_html, True, 'main-actions'))

    gate_html = []
    for gate in gates.get('gates', []):
        issues = (gate.get('fail') or gate.get('warn') or [])[:4]
        issue_txt = '<br>'.join(escape(x) for x in issues) if issues else 'Блокирующих замечаний нет.'
        gate_html.append(f"""<div class="gate {escape(gate['status'])}">
 <b><span class="st {escape(gate['status'])}">{escape(STATUS_RU.get(gate['status'], gate['status']))}</span> {escape(gate['name'])}</b>
 <p>{issue_txt}</p></div>""")
    parts.append(section('Проверка готовности к production', f'<div class="gates">{"".join(gate_html)}</div>', True))

    miss = comp.get('missing') or []
    if miss:
        rows = ''.join(
            f'<tr><td><span class="st {"fail" if i["priority"]=="high" else "warn" if i["priority"]=="medium" else "unknown"}">{escape(i["priority"])}</span></td>'
            f'<td>{escape(i["area"])}</td><td>{escape(i["question"])}</td><td>{escape(i["why"])}</td></tr>'
            for i in miss)
        miss_html = f'<table class="check"><thead><tr><th>Приоритет</th><th>Область</th><th>Что нужно уточнить</th><th>Почему это важно</th></tr></thead><tbody>{rows}</tbody></table>'
    else:
        miss_html = '<p>Критичных пропусков во вводных не найдено. При этом ревью контрактов и тест-плана всё равно нужно.</p>'
    parts.append(section('Какие вводные нужно уточнить', miss_html, True, 'missing-inputs'))

    items = checklist.get('items') or []
    if items:
        rows = ''.join(
            f'<tr><td>{escape(i["area"])}</td><td><span class="st {escape(i["status"])}">{escape(STATUS_RU.get(i["status"], i["status"]))}</span></td>'
            f'<td><b>{escape(i["title"])}</b><br><span class="hint">{escape(i["check"])}</span></td>'
            f'<td>{escape(i["fix"])}{_fix_link(i.get("title"), i.get("fix")) if i.get("status") == "fail" else ""}</td></tr>'
            for i in items)
        counts = checklist.get('counters') or {}
        checklist_html = (f'<p class="hint">Блокируют выпуск: {counts.get("fail",0)}, требуют проверки: {counts.get("warn",0)}, '
                          f'не указано: {counts.get("unknown",0)}, OK: {counts.get("ok",0)}.</p>'
                          f'<table class="check"><thead><tr><th>Область</th><th>Статус</th><th>Что проверяется</th><th>Как закрыть пункт</th></tr></thead><tbody>{rows}</tbody></table>')
    else:
        checklist_html = '<p>Архитектурный чек-лист не рассчитан.</p>'
    parts.append(section('Обязательный архитектурный чек-лист', checklist_html, False, 'checklist'))

    radar = res.get('detail_radar') or {'summary': 'Матрица деталей не рассчитана.', 'probes': []}
    probes = radar.get('probes') or []
    if probes:
        rows = ''.join(
            f'<tr><td>{escape(i["area"])}</td><td><span class="st {escape(i["status"])}">{escape(STATUS_RU.get(i["status"], i["status"]))}</span></td>'
            f'<td><b>{escape(i["title"])}</b><br><span class="hint">{escape(i["question"])}</span></td>'
            f'<td>{escape(i["why"])}</td><td>{escape(i["how"])}' +
            (('<br><span class="hint">Примеры: ' + escape('; '.join(i.get('examples') or [])) + '</span>') if i.get('examples') else '') +
            '</td></tr>'
            for i in probes)
        radar_html = (f'<p class="hint">{escape(radar.get("summary", ""))}</p>'
                      f'<table class="check"><thead><tr><th>Область</th><th>Статус</th><th>Что проверить</th><th>Почему важно</th><th>Как закрыть</th></tr></thead><tbody>{rows}</tbody></table>')
    else:
        radar_html = '<p>Матрица деталей не рассчитана.</p>'
    parts.append(section('Матрица деталей, которые нельзя забыть', radar_html, False, 'detail-radar'))

    alt_html = []
    for alt in res.get('alternatives', []):
        changes = ''.join(f'<li>{escape(c)}</li>' for c in alt.get('changes', []))
        must_count = len([x for x in alt.get('must_close', []) if x.strip()])
        close = f'<p><b>Перед внедрением закрыть:</b> блокеры из раздела «Найденные риски». Количество классов блокеров: {must_count}.</p>' if must_count else ''
        alt_html.append(f"""<div class="alt"><h3>{escape(alt['name'])}</h3>
 <p><b>Когда применять:</b> этот вариант подходит, когда {escape(alt['when'])}</p>
 <p><b>Оценка:</b> стоимость — {escape(alt['cost'])}; надёжность — {escape(alt['reliability'])}; риск — {escape(alt['risk'])}.</p>
 <ul>{changes}</ul>{close}<p class="hint">{escape(alt.get('not_enough',''))}</p></div>""")
    parts.append(section('Варианты архитектурного решения', ''.join(alt_html) or '<p>Варианты архитектурного решения не рассчитаны.</p>', False))

    scenario = res.get('scenario') or {}
    if scenario:
        main_html = []
        for st in scenario.get('main_flow', []):
            ctrls = ''.join(f'<li>{escape(x)}</li>' for x in st.get('controls', []))
            main_html.append(f'''<div class="flowbox"><h3>{st['order']}. {escape(st['title'])}</h3>
 <div class="meta">Канал: {escape(st['channel'])} · зависит от: {escape(str(st['depends_on']))}</div>
 <p>{escape(st['what_happens'])}</p><p><b>Результат:</b> {escape(st['result'])}</p>
 <ul>{ctrls}</ul><p><b>При ошибке:</b> {escape(st['failure_handling'])}</p></div>''')
        alt_html2 = []
        for alt in scenario.get('alternative_flows', []):
            steps_html = ''.join(f'<li>{escape(x)}</li>' for x in alt.get('steps', []))
            ctrls = '; '.join(alt.get('controls', []))
            alt_html2.append(f'''<div class="flowbox"><h3>{escape(alt['name'])}</h3>
 <p><b>Когда возникает:</b> {escape(alt['trigger'])}</p><ul>{steps_html}</ul>
 <p><b>Ожидаемый результат:</b> {escape(alt['result'])}</p><p class="hint">Контроли: {escape(ctrls)}</p></div>''')
        err_html = []
        for err in scenario.get('error_flows', [])[:10]:
            count = f' · затронуто мест: {err.get("affected_count")}' if err.get('affected_count',1)>1 else ''
            err_html.append(f'''<div class="flowbox"><h3>{escape(err['name'])}{escape(count)}</h3>
 <div class="meta">{escape(err.get('where',''))}</div><p><b>Что может пойти не так:</b> {escape(err['failure'])}</p>
 <p><b>Как должно обрабатываться:</b> {escape(err['expected_handling'])}</p></div>''')
        tasks = ''.join(f'<li>{escape(x)}</li>' for x in scenario.get('development_tasks', []))
        acc = ''.join(f'<li>{escape(x)}</li>' for x in scenario.get('acceptance_criteria', []))
        scen_html = f'''<p class="hint">Рекомендуемая статусная модель: {escape(', '.join(scenario.get('statuses', [])))}</p>
 <h3>Основной сценарий</h3>{''.join(main_html) or '<p>Основной сценарий не рассчитан.</p>'}
 <h3>Альтернативные сценарии</h3>{''.join(alt_html2) or '<p>Альтернативные сценарии не рассчитаны.</p>'}
 <h3>Ошибки, которые нужно учесть</h3>{''.join(err_html) or '<p>Ошибочные сценарии не рассчитаны.</p>'}
 <div class="two"><div><h3>Перенести в разработку</h3><ol class="tests">{tasks}</ol></div>
 <div><h3>Критерии приёмки</h3><ol class="tests">{acc}</ol></div></div>'''
    else:
        scen_html = '<p>Сценарная основа не рассчитана.</p>'
    parts.append(section('Сценарная основа для разработки', scen_html, False, 'scenario-base'))

    fhtml = []
    last = None
    for f in finding_groups:
        if f['severity'] != last:
            last = f['severity']
            fhtml.append(f'<p><span class="badge b-{f["severity"]}">{SEVERITY_RU[f["severity"]]}</span></p>')
        affected = f.get('affected') or []
        affected_preview = affected[:12]
        tail = len(affected) - len(affected_preview)
        affected_html = ''
        if f.get('count', 1) > 1:
            items = ''.join(f'<li>{escape(x)}</li>' for x in affected_preview)
            if tail > 0:
                items += f'<li>Ещё затронуто мест: {tail}.</li>'
            affected_html = f'<details><summary>Показать затронутые места</summary><ul>{items}</ul></details>'
        count_txt = f' · затронуто мест: {f.get("count")}' if f.get('count', 1) > 1 else ''
        fhtml.append(f"""<div class="finding {f['severity']}">
 <h3>{escape(f['title'])}</h3><div class="where">{escape(f.get('where_summary') or f.get('where') or '—')}{escape(count_txt)} · {escape(f['category'])} · {escape(f['rule'])}</div>
 <p><b>Почему это важно:</b> {escape(f['why'])}</p><p><b>Что нужно сделать:</b> {escape(f['fix'])}</p>{_fix_link(f.get('title'), f.get('fix'))}{affected_html}</div>""")
    if not finding_groups:
        fhtml.append('<p>Структурных проблем не обнаружено. Это не отменяет ревью контрактов, тестов и эксплуатационных требований.</p>')
    parts.append(section('Найденные риски и слабые места', ''.join(fhtml), True, 'risk-list'))

    pats = ''.join(
        f'<div class="pat"><b>{escape(p["name"])}</b> — {escape(p["why"])}<br><span class="ctl">обязательные контроли: {escape("; ".join(p["controls"]))}</span></div>'
        for p in res['patterns']) or '<p>Дополнительные архитектурные паттерны не требуются по текущим вводным.</p>'
    parts.append(section('Рекомендуемые архитектурные паттерны', pats, False, 'patterns'))

    parts.append(section('Карта процесса и последовательность взаимодействий',
                         f'<div class="mermaid">{escape(res["diagrams"]["flow"])}</div><div class="mermaid">{escape(res["diagrams"]["sequence"])}</div>', False))

    parts.append(section('Предлагаемая структура базы данных',
                         f'<p class="hint">В проекте могут понадобиться следующие таблицы: {escape(", ".join(res["schema"]["tables"]))}</p><pre>{escape(res["schema"]["ddl"])}</pre>', False))

    dor = ''.join(f'<li>{escape(x)}</li>' for x in artifacts.get('definition_of_ready', []))
    dod = ''.join(f'<li>{escape(x)}</li>' for x in artifacts.get('definition_of_done', []))
    mon = ''.join(f'<li>{escape(x)}</li>' for x in artifacts.get('monitoring', []))
    contract = artifacts.get('event_contract_skeleton') or {}
    contract_txt = '\n'.join(f'{k}: {v}' for k, v in contract.items())
    artifacts_html = f"""<div class="two"><div><h3>Definition of Ready</h3><ol class="tests">{dor}</ol></div>
 <div><h3>Definition of Done</h3><ol class="tests">{dod}</ol></div></div>
 <h3>Мониторинг и эксплуатационные метрики</h3><ol class="tests">{mon}</ol>
 <h3>Черновик контракта события</h3><pre>{escape(contract_txt)}</pre>"""
    parts.append(section('Проектные артефакты для аналитика и команды', artifacts_html, False, 'artifacts'))

    tests = ''.join(f'<li>{escape(t)}</li>' for t in res['tests'])
    parts.append(section('Чек-лист проверок и тестов', f'<ol class="tests">{tests}</ol>', False))

    return page(f"Разбор: {m['name']}", ''.join(parts), MERMAID_HEAD)
