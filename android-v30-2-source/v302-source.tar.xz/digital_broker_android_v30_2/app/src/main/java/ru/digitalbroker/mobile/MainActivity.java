package ru.digitalbroker.mobile;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.NumberFormat;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int PRIMARY = Color.rgb(11, 87, 208);
    private static final int TEXT = Color.rgb(23, 33, 43);
    private static final int SECONDARY = Color.rgb(95, 107, 118);
    private static final int SURFACE = Color.WHITE;
    private static final int BACKGROUND = Color.rgb(244, 246, 248);
    private static final int SUCCESS = Color.rgb(19, 115, 51);
    private static final int WARNING = Color.rgb(176, 96, 0);
    private static final int DANGER = Color.rgb(179, 38, 30);

    private EditText capitalInput;
    private Button calculateButton;
    private ProgressBar progress;
    private TextView statusText;
    private TextView dataText;
    private LinearLayout resultContainer;
    private MarketDataService marketDataService;
    private final RecommendationEngine engine = new RecommendationEngine();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        marketDataService = new MarketDataService(this);
        setContentView(buildUi());
        capitalInput.setText(getPreferences(MODE_PRIVATE).getString("capital", "20000"));
        calculateButton.setOnClickListener(v -> refreshAndCalculate());
        refreshAndCalculate();
    }

    @Override
    protected void onDestroy() {
        marketDataService.shutdown();
        super.onDestroy();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BACKGROUND);
        LinearLayout root = vertical(0);
        root.setPadding(dp(16), dp(18), dp(16), dp(28));
        scroll.addView(root, matchWrap());

        TextView title = text("Digital Broker", 28, TEXT, true);
        root.addView(title);
        TextView subtitle = text("v30.3 Mobile Shadow · рекомендации без автоматических сделок", 14, SECONDARY, false);
        subtitle.setPadding(0, dp(4), 0, dp(14));
        root.addView(subtitle);

        LinearLayout warningCard = card();
        TextView warningTitle = text("SHADOW ONLY / NO-GO", 15, DANGER, true);
        warningCard.addView(warningTitle);
        TextView warningBody = text("Приложение рассчитывает распределение капитала, но не отправляет заявки брокеру. Доходность не гарантируется.", 13, SECONDARY, false);
        warningBody.setPadding(0, dp(5), 0, 0);
        warningCard.addView(warningBody);
        root.addView(warningCard, cardParams());

        LinearLayout inputCard = card();
        inputCard.addView(text("Сумма капитала", 16, TEXT, true));
        capitalInput = new EditText(this);
        capitalInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        capitalInput.setTextSize(22);
        capitalInput.setTextColor(TEXT);
        capitalInput.setSingleLine(true);
        capitalInput.setHint("20 000 ₽");
        capitalInput.setPadding(dp(12), dp(10), dp(12), dp(10));
        inputCard.addView(capitalInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView limit = text("Допустимый диапазон: 1 000–100 000 ₽", 12, SECONDARY, false);
        limit.setPadding(0, dp(4), 0, dp(8));
        inputCard.addView(limit);
        calculateButton = new Button(this);
        calculateButton.setText("ОБНОВИТЬ ДАННЫЕ И РАССЧИТАТЬ");
        calculateButton.setTextColor(Color.WHITE);
        calculateButton.setTextSize(13);
        calculateButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        calculateButton.setBackgroundColor(PRIMARY);
        calculateButton.setPadding(dp(10), dp(12), dp(10), dp(12));
        inputCard.addView(calculateButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        root.addView(inputCard, cardParams());

        LinearLayout statusCard = card();
        LinearLayout statusRow = horizontal();
        progress = new ProgressBar(this);
        statusRow.addView(progress, new LinearLayout.LayoutParams(dp(32), dp(32)));
        statusText = text("Проверяю данные…", 15, TEXT, true);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        statusLp.setMargins(dp(10), 0, 0, 0);
        statusRow.addView(statusText, statusLp);
        statusCard.addView(statusRow);
        dataText = text("MOEX: SBMX / SBGD / LQDT · ЦБ: золото", 12, SECONDARY, false);
        dataText.setPadding(0, dp(8), 0, 0);
        statusCard.addView(dataText);
        root.addView(statusCard, cardParams());

        resultContainer = vertical(0);
        root.addView(resultContainer);

        TextView footer = text("Перед покупкой проверьте цены и спред у брокера. Приложение использует только длинные позиции и не рассчитывает плечо, short или долг.", 12, SECONDARY, false);
        footer.setPadding(dp(4), dp(8), dp(4), 0);
        root.addView(footer);
        return scroll;
    }

    private void refreshAndCalculate() {
        hideKeyboard();
        Double capital = parseCapital();
        if (capital == null) {
            statusText.setText("Введите корректную сумму капитала");
            statusText.setTextColor(DANGER);
            return;
        }
        getPreferences(MODE_PRIVATE).edit().putString("capital", String.valueOf(capital.longValue())).apply();
        setLoading(true, "Получаю актуальные данные MOEX и Банка России…");
        resultContainer.removeAllViews();
        marketDataService.refresh(new MarketDataService.Callback() {
            @Override public void onSuccess(Models.MarketSnapshot snapshot) {
                Models.Recommendation recommendation = engine.recommend(capital, snapshot);
                runOnUiThread(() -> render(recommendation, snapshot));
            }
            @Override public void onError(String message, Throwable error) {
                runOnUiThread(() -> {
                    setLoading(false, "Расчёт заблокирован");
                    statusText.setTextColor(DANGER);
                    dataText.setText(message + (error == null ? "" : "\n" + error.getClass().getSimpleName()));
                    resultContainer.addView(messageCard("Нет свежих данных", message, DANGER));
                });
            }
        });
    }

    private void render(Models.Recommendation recommendation, Models.MarketSnapshot snapshot) {
        setLoading(false, recommendation.actionable ? "Рекомендация рассчитана" : "Расчёт заблокирован");
        statusText.setTextColor(recommendation.actionable ? SUCCESS : DANGER);
        dataText.setText("Данные на " + recommendation.dataDate + " · обновлено " + snapshot.retrievedAt +
                (snapshot.fromCache ? " · локальный кэш" : " · официальные источники"));
        resultContainer.removeAllViews();

        LinearLayout summary = card();
        TextView risk = text("Режим риска: " + recommendation.riskState, 18, riskColor(recommendation.riskState), true);
        summary.addView(risk);
        summary.addView(paddedText("Лидер: " + recommendation.leader, 14, TEXT, true));
        summary.addView(paddedText(recommendation.explanation, 13, SECONDARY, false));
        resultContainer.addView(summary, cardParams());

        if (recommendation.actionable) {
            LinearLayout allocationCard = card();
            allocationCard.addView(text("Распределение капитала", 18, TEXT, true));
            for (Models.Allocation allocation : recommendation.allocations) {
                allocationCard.addView(allocationRow(allocation));
            }
            LinearLayout cashRow = horizontal();
            TextView cashName = text("Свободные рубли / резерв", 14, TEXT, true);
            TextView cashValue = text(formatRub(recommendation.cashRub), 14, PRIMARY, true);
            cashValue.setGravity(Gravity.END);
            cashRow.setPadding(0, dp(14), 0, 0);
            cashRow.addView(cashName, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            cashRow.addView(cashValue, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            allocationCard.addView(cashRow);
            resultContainer.addView(allocationCard, cardParams());
        }

        if (!recommendation.warnings.isEmpty()) {
            StringBuilder body = new StringBuilder();
            for (String warning : recommendation.warnings) body.append("• ").append(warning).append('\n');
            resultContainer.addView(messageCard("Предупреждения", body.toString().trim(), WARNING), cardParams());
        }
    }

    private View allocationRow(Models.Allocation allocation) {
        LinearLayout box = vertical(0);
        box.setPadding(0, dp(14), 0, dp(2));
        LinearLayout top = horizontal();
        TextView name = text(allocation.secid + " · " + allocation.name, 15, TEXT, true);
        TextView weight = text(allocation.percentText(), 15, PRIMARY, true);
        weight.setGravity(Gravity.END);
        top.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.5f));
        top.addView(weight, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.5f));
        box.addView(top);
        String details = allocation.units + " паёв × " + formatRub(allocation.price) +
                " ≈ " + formatRub(allocation.estimatedRub) +
                " · целевая сумма " + formatRub(allocation.targetRub);
        box.addView(paddedText(details, 12, SECONDARY, false));
        return box;
    }

    private LinearLayout messageCard(String title, String body, int titleColor) {
        LinearLayout card = card();
        card.addView(text(title, 16, titleColor, true));
        card.addView(paddedText(body, 13, SECONDARY, false));
        return card;
    }

    private void setLoading(boolean loading, String text) {
        progress.setVisibility(loading ? View.VISIBLE : View.GONE);
        calculateButton.setEnabled(!loading);
        statusText.setText(text);
        statusText.setTextColor(TEXT);
    }

    private Double parseCapital() {
        try {
            String raw = capitalInput.getText().toString().replace(" ", "").replace(',', '.').trim();
            double value = Double.parseDouble(raw);
            return Double.isFinite(value) ? value : null;
        } catch (Exception ignored) {
            return null;
        }
    }

    private void hideKeyboard() {
        View focused = getCurrentFocus();
        if (focused != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(focused.getWindowToken(), 0);
        }
    }

    private int riskColor(String risk) {
        if ("GREEN".equals(risk)) return SUCCESS;
        if ("YELLOW".equals(risk) || "ORANGE".equals(risk)) return WARNING;
        return DANGER;
    }

    private static String formatRub(double value) {
        NumberFormat format = NumberFormat.getNumberInstance(new Locale("ru", "RU"));
        format.setMaximumFractionDigits(2);
        return format.format(value) + " ₽";
    }

    private LinearLayout card() {
        LinearLayout card = vertical(dp(12));
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackgroundColor(SURFACE);
        card.setElevation(dp(2));
        return card;
    }

    private LinearLayout vertical(int spacing) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.START);
        return layout;
    }

    private LinearLayout horizontal() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(color);
        view.setLineSpacing(0f, 1.12f);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private TextView paddedText(String value, int sp, int color, boolean bold) {
        TextView view = text(value, sp, color, bold);
        view.setPadding(0, dp(8), 0, 0);
        return view;
    }

    private LinearLayout.LayoutParams cardParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(12));
        return lp;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
