package ru.digitalbroker.mobile;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.xml.parsers.DocumentBuilderFactory;

final class MarketDataService {
    interface Callback {
        void onSuccess(Models.MarketSnapshot snapshot);
        void onError(String message, Throwable error);
    }

    private static final String PREFS = "market_cache_v302";
    private static final String CACHE_KEY = "snapshot";
    private static final String RETRIEVED_KEY = "retrieved_at_epoch";
    private static final int CONNECT_TIMEOUT_MS = 15_000;
    private static final int READ_TIMEOUT_MS = 25_000;
    private static final int MAX_CACHE_AGE_HOURS = 96;
    private final Context context;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    MarketDataService(Context context) {
        this.context = context.getApplicationContext();
    }

    void refresh(Callback callback) {
        executor.execute(() -> {
            try {
                Models.MarketSnapshot snapshot = fetchOnline();
                saveCache(snapshot);
                callback.onSuccess(snapshot);
            } catch (Throwable onlineError) {
                try {
                    Models.MarketSnapshot cache = loadCache();
                    callback.onSuccess(cache);
                } catch (Throwable cacheError) {
                    callback.onError("Не удалось получить официальные данные MOEX/ЦБ и нет свежего локального кэша.", onlineError);
                }
            }
        });
    }

    void shutdown() {
        executor.shutdownNow();
    }

    private Models.MarketSnapshot fetchOnline() throws Exception {
        LocalDate end = LocalDate.now();
        LocalDate start = end.minusDays(550);
        Models.InstrumentData sbmx = fetchInstrument("SBMX", "Российские акции", start, end);
        Models.InstrumentData sbgd = fetchInstrument("SBGD", "Золото", start, end);
        Models.InstrumentData lqdt = fetchInstrument("LQDT", "Денежный рынок", start, end);
        List<Models.PricePoint> gold = fetchCbrGold(start.minusDays(120), end);
        if (gold.size() < 253) throw new IllegalStateException("CBR_GOLD_HISTORY_TOO_SHORT:" + gold.size());
        return new Models.MarketSnapshot(sbmx, sbgd, lqdt, gold, Instant.now().toString(), false);
    }

    private Models.InstrumentData fetchInstrument(String secid, String name, LocalDate start, LocalDate end) throws Exception {
        List<Models.PricePoint> history = fetchMoexHistory(secid, start, end);
        if (history.size() < 253) throw new IllegalStateException(secid + "_HISTORY_TOO_SHORT:" + history.size());
        Quote quote = fetchMoexQuote(secid);
        Models.PricePoint last = history.get(history.size() - 1);
        double price = quote.price > 0 ? quote.price : last.close;
        String date = quote.date != null && !quote.date.trim().isEmpty() ? quote.date : last.date;
        int lot = Math.max(1, quote.lotSize);
        return new Models.InstrumentData(secid, name, price, lot, date, history, quote.liquidityRub);
    }

    private List<Models.PricePoint> fetchMoexHistory(String secid, LocalDate start, LocalDate end) throws Exception {
        Map<String, Models.PricePoint> byDate = new LinkedHashMap<>();
        int offset = 0;
        for (int page = 0; page < 20; page++) {
            String url = "https://iss.moex.com/iss/history/engines/stock/markets/shares/securities/" + secid + ".json" +
                    "?from=" + start + "&till=" + end + "&start=" + offset + "&limit=100" +
                    "&iss.meta=off&iss.only=history&history.columns=TRADEDATE,BOARDID,CLOSE,LEGALCLOSEPRICE,VALUE";
            JSONObject root = new JSONObject(getText(url));
            JSONObject block = root.getJSONObject("history");
            JSONArray columns = block.getJSONArray("columns");
            JSONArray rows = block.getJSONArray("data");
            if (rows.length() == 0) break;
            Map<String, Integer> index = columnIndex(columns);
            for (int i = 0; i < rows.length(); i++) {
                JSONArray row = rows.getJSONArray(i);
                String board = optString(row, index.get("BOARDID"));
                if (!("TQBR".equals(board) || "TQTF".equals(board))) continue;
                String date = optString(row, index.get("TRADEDATE"));
                double close = optDouble(row, index.get("CLOSE"));
                if (!(close > 0)) close = optDouble(row, index.get("LEGALCLOSEPRICE"));
                if (date == null || date.trim().isEmpty() || !(close > 0)) continue;
                Models.PricePoint existing = byDate.get(date);
                if (existing == null || "TQBR".equals(board)) byDate.put(date, new Models.PricePoint(date, close));
            }
            offset += rows.length();
            if (rows.length() < 100) break;
        }
        List<Models.PricePoint> out = new ArrayList<>(byDate.values());
        out.sort(Comparator.comparing(x -> x.date));
        return out;
    }

    private Quote fetchMoexQuote(String secid) throws Exception {
        String url = "https://iss.moex.com/iss/engines/stock/markets/shares/securities/" + secid + ".json" +
                "?iss.meta=off&iss.only=securities,marketdata" +
                "&securities.columns=SECID,BOARDID,LOTSIZE,PREVPRICE" +
                "&marketdata.columns=SECID,BOARDID,LAST,MARKETPRICE,LCURRENTPRICE,UPDATETIME,SYSTIME,VALTODAY_RUR";
        JSONObject root = new JSONObject(getText(url));
        JSONObject securities = root.getJSONObject("securities");
        JSONObject market = root.getJSONObject("marketdata");
        Map<String, Integer> si = columnIndex(securities.getJSONArray("columns"));
        Map<String, Integer> mi = columnIndex(market.getJSONArray("columns"));
        JSONArray srows = securities.getJSONArray("data");
        JSONArray mrows = market.getJSONArray("data");
        Map<String, JSONArray> securityByBoard = new HashMap<>();
        for (int i = 0; i < srows.length(); i++) {
            JSONArray row = srows.getJSONArray(i);
            String board = optString(row, si.get("BOARDID"));
            if ("TQBR".equals(board) || "TQTF".equals(board)) securityByBoard.put(board, row);
        }
        JSONArray selectedMarket = null;
        String selectedBoard = null;
        for (String board : new String[]{"TQBR", "TQTF"}) {
            for (int i = 0; i < mrows.length(); i++) {
                JSONArray row = mrows.getJSONArray(i);
                if (!board.equals(optString(row, mi.get("BOARDID")))) continue;
                double p = firstPositive(row, mi, "LAST", "MARKETPRICE", "LCURRENTPRICE");
                if (p > 0) {
                    selectedMarket = row;
                    selectedBoard = board;
                    break;
                }
            }
            if (selectedMarket != null) break;
        }
        if (selectedMarket == null) throw new IllegalStateException(secid + "_QUOTE_NOT_FOUND");
        JSONArray srow = securityByBoard.get(selectedBoard);
        int lot = srow == null ? 1 : (int) Math.round(optDouble(srow, si.get("LOTSIZE")));
        double price = firstPositive(selectedMarket, mi, "LAST", "MARKETPRICE", "LCURRENTPRICE");
        double liquidity = optDouble(selectedMarket, mi.get("VALTODAY_RUR"));
        String system = optString(selectedMarket, mi.get("SYSTIME"));
        String date = system != null && system.length() >= 10 ? system.substring(0, 10) : LocalDate.now().toString();
        return new Quote(price, Math.max(1, lot), date, Math.max(0.0, liquidity));
    }

    private List<Models.PricePoint> fetchCbrGold(LocalDate start, LocalDate end) throws Exception {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.US);
        String url = "https://www.cbr.ru/scripts/xml_metall.asp?date_req1=" +
                URLEncoder.encode(start.format(fmt), StandardCharsets.UTF_8.name()) + "&date_req2=" +
                URLEncoder.encode(end.format(fmt), StandardCharsets.UTF_8.name());
        byte[] raw = getBytes(url);
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
        factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        Document document = factory.newDocumentBuilder().parse(new ByteArrayInputStream(raw));
        NodeList records = document.getElementsByTagName("Record");
        List<Models.PricePoint> out = new ArrayList<>();
        DateTimeFormatter cbrDate = DateTimeFormatter.ofPattern("dd.MM.yyyy", Locale.US);
        for (int i = 0; i < records.getLength(); i++) {
            Node node = records.item(i);
            if (!(node instanceof Element element)) continue;
            String code = element.getAttribute("Code");
            if (!code.trim().isEmpty() && !"1".equals(code)) continue;
            String rawDate = element.getAttribute("Date");
            if (rawDate.trim().isEmpty()) continue;
            double buy = childNumber(element, "Buy");
            double sell = childNumber(element, "Sell");
            double value;
            if (buy > 0 && sell > 0) value = (buy + sell) / 2.0;
            else value = Math.max(buy, sell);
            if (!(value > 0)) continue;
            LocalDate date = LocalDate.parse(rawDate, cbrDate);
            out.add(new Models.PricePoint(date.toString(), value));
        }
        out.sort(Comparator.comparing(x -> x.date));
        Map<String, Models.PricePoint> unique = new LinkedHashMap<>();
        for (Models.PricePoint point : out) unique.put(point.date, point);
        return new ArrayList<>(unique.values());
    }

    private static double childNumber(Element element, String tag) {
        NodeList list = element.getElementsByTagName(tag);
        if (list.getLength() == 0) return 0.0;
        String text = list.item(0).getTextContent();
        if (text == null) return 0.0;
        try {
            return Double.parseDouble(text.replace("\u00a0", "").replace(" ", "").replace(',', '.').trim());
        } catch (Exception ignored) {
            return 0.0;
        }
    }

    private static String getText(String url) throws Exception {
        return new String(getBytes(url), StandardCharsets.UTF_8);
    }

    private static byte[] getBytes(String urlText) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(urlText).openConnection();
        connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
        connection.setReadTimeout(READ_TIMEOUT_MS);
        connection.setRequestProperty("User-Agent", "DigitalBrokerMobile/30.2.2 Android");
        connection.setRequestProperty("Accept", "application/json, application/xml, text/xml, */*");
        connection.setInstanceFollowRedirects(true);
        int code = connection.getResponseCode();
        InputStream input = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
        if (input == null) throw new IllegalStateException("HTTP_" + code + "_NO_BODY");
        try (BufferedInputStream in = new BufferedInputStream(input); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) >= 0) out.write(buffer, 0, n);
            if (code < 200 || code >= 300) throw new IllegalStateException("HTTP_" + code + ":" + new String(out.toByteArray(), StandardCharsets.UTF_8));
            return out.toByteArray();
        } finally {
            connection.disconnect();
        }
    }

    private void saveCache(Models.MarketSnapshot snapshot) throws Exception {
        JSONObject root = snapshotToJson(snapshot);
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(CACHE_KEY, root.toString())
                .putLong(RETRIEVED_KEY, System.currentTimeMillis())
                .apply();
    }

    private Models.MarketSnapshot loadCache() throws Exception {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long retrieved = prefs.getLong(RETRIEVED_KEY, 0L);
        long ageHours = (System.currentTimeMillis() - retrieved) / 3_600_000L;
        if (retrieved <= 0 || ageHours > MAX_CACHE_AGE_HOURS) throw new IllegalStateException("CACHE_STALE");
        String raw = prefs.getString(CACHE_KEY, null);
        if (raw == null || raw.trim().isEmpty()) throw new IllegalStateException("CACHE_EMPTY");
        return snapshotFromJson(new JSONObject(raw), true);
    }

    private static JSONObject snapshotToJson(Models.MarketSnapshot snapshot) throws Exception {
        JSONObject root = new JSONObject();
        root.put("retrievedAt", snapshot.retrievedAt);
        root.put("sbmx", instrumentToJson(snapshot.sbmx));
        root.put("sbgd", instrumentToJson(snapshot.sbgd));
        root.put("lqdt", instrumentToJson(snapshot.lqdt));
        root.put("cbrGold", pointsToJson(snapshot.cbrGold));
        return root;
    }

    private static Models.MarketSnapshot snapshotFromJson(JSONObject root, boolean fromCache) throws Exception {
        return new Models.MarketSnapshot(
                instrumentFromJson(root.getJSONObject("sbmx")),
                instrumentFromJson(root.getJSONObject("sbgd")),
                instrumentFromJson(root.getJSONObject("lqdt")),
                pointsFromJson(root.getJSONArray("cbrGold")),
                root.getString("retrievedAt"), fromCache);
    }

    private static JSONObject instrumentToJson(Models.InstrumentData i) throws Exception {
        JSONObject o = new JSONObject();
        o.put("secid", i.secid);
        o.put("name", i.name);
        o.put("currentPrice", i.currentPrice);
        o.put("lotSize", i.lotSize);
        o.put("currentDate", i.currentDate);
        o.put("liquidityRub", i.liquidityRub);
        o.put("history", pointsToJson(i.history));
        return o;
    }

    private static Models.InstrumentData instrumentFromJson(JSONObject o) throws Exception {
        return new Models.InstrumentData(o.getString("secid"), o.getString("name"),
                o.getDouble("currentPrice"), o.getInt("lotSize"), o.getString("currentDate"),
                pointsFromJson(o.getJSONArray("history")), o.optDouble("liquidityRub", 0.0));
    }

    private static JSONArray pointsToJson(List<Models.PricePoint> points) throws Exception {
        JSONArray array = new JSONArray();
        for (Models.PricePoint p : points) {
            JSONArray row = new JSONArray();
            row.put(p.date);
            row.put(p.close);
            array.put(row);
        }
        return array;
    }

    private static List<Models.PricePoint> pointsFromJson(JSONArray array) throws Exception {
        List<Models.PricePoint> out = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            JSONArray row = array.getJSONArray(i);
            out.add(new Models.PricePoint(row.getString(0), row.getDouble(1)));
        }
        return out;
    }

    private static Map<String, Integer> columnIndex(JSONArray columns) throws Exception {
        Map<String, Integer> out = new HashMap<>();
        for (int i = 0; i < columns.length(); i++) out.put(columns.getString(i), i);
        return out;
    }

    private static String optString(JSONArray row, Integer index) {
        if (index == null || index < 0 || index >= row.length() || row.isNull(index)) return null;
        return row.optString(index, null);
    }

    private static double optDouble(JSONArray row, Integer index) {
        if (index == null || index < 0 || index >= row.length() || row.isNull(index)) return 0.0;
        Object value = row.opt(index);
        if (value instanceof Number number) return number.doubleValue();
        try { return Double.parseDouble(String.valueOf(value).replace(',', '.')); }
        catch (Exception ignored) { return 0.0; }
    }

    private static double firstPositive(JSONArray row, Map<String, Integer> index, String... names) {
        for (String name : names) {
            double value = optDouble(row, index.get(name));
            if (value > 0) return value;
        }
        return 0.0;
    }

    private static final class Quote {
        final double price;
        final int lotSize;
        final String date;
        final double liquidityRub;
        Quote(double price, int lotSize, String date, double liquidityRub) {
            this.price = price;
            this.lotSize = lotSize;
            this.date = date;
            this.liquidityRub = liquidityRub;
        }
    }
}
