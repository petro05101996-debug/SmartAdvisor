package ru.digitalbroker.mobile;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

final class Models {
    static final class PricePoint {
        final String date;
        final double close;
        PricePoint(String date, double close) {
            this.date = date;
            this.close = close;
        }
    }

    static final class InstrumentData {
        final String secid;
        final String name;
        final double currentPrice;
        final int lotSize;
        final String currentDate;
        final List<PricePoint> history;
        final double liquidityRub;

        InstrumentData(String secid, String name, double currentPrice, int lotSize,
                       String currentDate, List<PricePoint> history, double liquidityRub) {
            this.secid = secid;
            this.name = name;
            this.currentPrice = currentPrice;
            this.lotSize = lotSize;
            this.currentDate = currentDate;
            this.history = Collections.unmodifiableList(new ArrayList<>(history));
            this.liquidityRub = liquidityRub;
        }
    }

    static final class MarketSnapshot {
        final InstrumentData sbmx;
        final InstrumentData sbgd;
        final InstrumentData lqdt;
        final List<PricePoint> cbrGold;
        final String retrievedAt;
        final boolean fromCache;

        MarketSnapshot(InstrumentData sbmx, InstrumentData sbgd, InstrumentData lqdt,
                       List<PricePoint> cbrGold, String retrievedAt, boolean fromCache) {
            this.sbmx = sbmx;
            this.sbgd = sbgd;
            this.lqdt = lqdt;
            this.cbrGold = Collections.unmodifiableList(new ArrayList<>(cbrGold));
            this.retrievedAt = retrievedAt;
            this.fromCache = fromCache;
        }
    }

    static final class Allocation {
        final String secid;
        final String name;
        final double weight;
        final double targetRub;
        final long units;
        final double estimatedRub;
        final double price;
        final int lotSize;

        Allocation(String secid, String name, double weight, double targetRub,
                   long units, double estimatedRub, double price, int lotSize) {
            this.secid = secid;
            this.name = name;
            this.weight = weight;
            this.targetRub = targetRub;
            this.units = units;
            this.estimatedRub = estimatedRub;
            this.price = price;
            this.lotSize = lotSize;
        }

        String percentText() {
            return String.format(Locale.US, "%.1f%%", weight * 100.0);
        }
    }

    static final class Recommendation {
        final String status;
        final String riskState;
        final String leader;
        final String dataDate;
        final List<Allocation> allocations;
        final double cashRub;
        final String explanation;
        final boolean actionable;
        final List<String> warnings;

        Recommendation(String status, String riskState, String leader, String dataDate,
                       List<Allocation> allocations, double cashRub, String explanation,
                       boolean actionable, List<String> warnings) {
            this.status = status;
            this.riskState = riskState;
            this.leader = leader;
            this.dataDate = dataDate;
            this.allocations = Collections.unmodifiableList(new ArrayList<>(allocations));
            this.cashRub = cashRub;
            this.explanation = explanation;
            this.actionable = actionable;
            this.warnings = Collections.unmodifiableList(new ArrayList<>(warnings));
        }
    }

    private Models() {}
}
