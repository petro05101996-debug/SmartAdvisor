package ru.digitalbroker.mobile;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

final class RecommendationEngine {
    static final double MIN_CAPITAL = 1_000.0;
    static final double MAX_CAPITAL = 100_000.0;
    private static final double FEE_RESERVE_RATE = 0.006;
    private static final double MIN_OPERATIONAL_CASH = 0.10;
    private static final double MAX_TOTAL_RISK = 0.90;
    private static final double MAX_SINGLE_RISK = 0.70;

    Models.Recommendation recommend(double capital, Models.MarketSnapshot snapshot) {
        List<String> warnings = new ArrayList<>();
        if (!Double.isFinite(capital) || capital < MIN_CAPITAL || capital > MAX_CAPITAL) {
            return blocked("BLOCKED_CAPITAL", "—", "—", latestDate(snapshot),
                    "Введите сумму от 1 000 до 100 000 ₽. Лимит соответствует подтверждённому диапазону мобильного shadow-пилота.",
                    warnings);
        }

        String latestDate = latestDate(snapshot);
        try {
            long age = Math.abs(ChronoUnit.DAYS.between(LocalDate.parse(latestDate), LocalDate.now()));
            if (age > 7) {
                warnings.add("Последняя биржевая дата старше 7 календарных дней: " + latestDate);
                return blocked("BLOCKED_STALE_DATA", "—", "—", latestDate,
                        "Расчёт заблокирован: официальные данные устарели. Обновите данные при стабильном интернете.", warnings);
            }
            if (age > 3) {
                warnings.add("Данные не сегодняшние; возможны выходные или перерыв торгов.");
            }
        } catch (Exception ex) {
            warnings.add("Не удалось проверить дату данных.");
            return blocked("BLOCKED_BAD_DATE", "—", "—", latestDate,
                    "Дата официальных данных не прошла проверку.", warnings);
        }

        Metrics broad = metrics(snapshot.sbmx.history);
        Metrics goldFund = metrics(snapshot.sbgd.history);
        Metrics cash = metrics(snapshot.lqdt.history);
        Metrics cbrGold = metrics(snapshot.cbrGold);

        if (!broad.complete || !goldFund.complete || !cash.complete || !cbrGold.complete) {
            warnings.add("Для одной или нескольких серий недостаточно истории.");
            return blocked("BLOCKED_INCOMPLETE_HISTORY", "—", "—", latestDate,
                    "Нужно минимум 252 наблюдения по фондам и достаточно данных ЦБ по золоту.", warnings);
        }

        double broadScore = scoreRiskAsset(broad, 0.0);
        double cbrBlend = 0.55 * cbrGold.mom63 + 0.45 * cbrGold.mom126;
        double goldScore = scoreRiskAsset(goldFund, cbrBlend);
        double cashCarry = Math.max(-0.01, Math.min(0.03, cash.mom63 / 3.0));
        double cashScore = 0.002 + 0.25 * cashCarry;

        Score broadRow = new Score("SBMX", "Российские акции", broadScore, broad);
        Score goldRow = new Score("SBGD", "Золото", goldScore, goldFund);
        List<Score> risky = new ArrayList<>(Arrays.asList(broadRow, goldRow));
        risky.sort(Comparator.comparingDouble((Score x) -> x.score).reversed());
        Score leader = risky.get(0);

        String riskState = riskState(leader, risky.get(1), broad, goldFund);
        double riskMultiplier = switch (riskState) {
            case "GREEN" -> 1.0;
            case "YELLOW" -> 0.90;
            case "ORANGE" -> 0.40;
            case "RED" -> 0.20;
            default -> 0.0;
        };

        Map<String, Double> weights = new LinkedHashMap<>();
        if (leader.score <= cashScore || (broadScore <= 0.0 && goldScore <= 0.0)) {
            weights.put("SBMX", 0.0);
            weights.put("SBGD", 0.0);
            weights.put("LQDT", 1.0);
            leader = new Score("LQDT", "Денежный рынок", cashScore, cash);
            riskState = "RED";
        } else {
            double strength = Math.tanh(Math.max(0.0, leader.score) / 0.08);
            double totalRisk = Math.min(MAX_TOTAL_RISK, MAX_TOTAL_RISK * strength) * riskMultiplier;
            totalRisk = Math.min(totalRisk, 1.0 - MIN_OPERATIONAL_CASH);
            List<Score> positive = new ArrayList<>();
            for (Score row : risky) if (row.score > 0) positive.add(row);
            double denom = 0.0;
            for (Score row : positive) denom += Math.pow(Math.max(row.score, 1e-9), 1.35);
            double used = 0.0;
            for (Score row : risky) {
                double w = 0.0;
                if (row.score > 0 && denom > 0) {
                    w = totalRisk * Math.pow(row.score, 1.35) / denom;
                    w = Math.min(MAX_SINGLE_RISK, w);
                }
                weights.put(row.secid, w);
                used += w;
            }
            weights.put("LQDT", Math.max(0.0, 1.0 - used));
            normalize(weights);
        }

        List<Models.Allocation> allocations = new ArrayList<>();
        double invested = 0.0;
        invested += addAllocation(allocations, snapshot.sbmx, weights.getOrDefault("SBMX", 0.0), capital);
        invested += addAllocation(allocations, snapshot.sbgd, weights.getOrDefault("SBGD", 0.0), capital);
        invested += addAllocation(allocations, snapshot.lqdt, weights.getOrDefault("LQDT", 0.0), capital);
        double cashRub = Math.max(0.0, capital - invested);

        if (cashRub > capital * 0.15 && weights.getOrDefault("LQDT", 0.0) > 0.25) {
            warnings.add("Из-за округления до целых паёв осталась повышенная сумма рублей.");
        }
        if (snapshot.fromCache) warnings.add("Использован локальный кэш; проверьте дату данных.");

        String explanation = explanation(leader, riskState, broadScore, goldScore, cashScore, weights);
        return new Models.Recommendation("PASS_SHADOW_RECOMMENDATION", riskState, leader.secid,
                latestDate, allocations, cashRub, explanation, true, warnings);
    }

    private static Models.Recommendation blocked(String status, String risk, String leader,
                                                  String date, String explanation, List<String> warnings) {
        return new Models.Recommendation(status, risk, leader, date, new ArrayList<>(), 0.0,
                explanation, false, warnings);
    }

    private static double addAllocation(List<Models.Allocation> out, Models.InstrumentData instrument,
                                        double weight, double capital) {
        double target = capital * Math.max(0.0, weight);
        double lotCost = instrument.currentPrice * instrument.lotSize;
        long lots = lotCost > 0 ? (long) Math.floor(target * (1.0 - FEE_RESERVE_RATE) / lotCost) : 0;
        long units = lots * instrument.lotSize;
        double estimated = units * instrument.currentPrice;
        out.add(new Models.Allocation(instrument.secid, instrument.name, weight, target, units,
                estimated, instrument.currentPrice, instrument.lotSize));
        return estimated;
    }

    private static String explanation(Score leader, String riskState, double broadScore,
                                      double goldScore, double cashScore, Map<String, Double> weights) {
        String regime = switch (riskState) {
            case "GREEN" -> "тренд устойчивый, риск не ограничен дополнительным защитным коэффициентом";
            case "YELLOW" -> "сигналы смешанные, риск немного снижен";
            case "ORANGE" -> "обнаружено ослабление тренда, большая часть капитала направлена в денежный рынок";
            case "RED" -> "защитный режим, приоритет денежного рынка";
            default -> "данные не прошли проверку";
        };
        return String.format(Locale.US,
                "Лидер: %s. Режим %s: %s. Баллы модели: SBMX %.4f, SBGD %.4f, LQDT %.4f. " +
                        "Итоговые доли: SBMX %.1f%%, SBGD %.1f%%, LQDT %.1f%%. " +
                        "Расчёт учитывает тренд 1/3/6/12 месяцев, волатильность, просадку и отдельный официальный ряд золота ЦБ.",
                leader.secid, riskState, regime, broadScore, goldScore, cashScore,
                100 * weights.getOrDefault("SBMX", 0.0),
                100 * weights.getOrDefault("SBGD", 0.0),
                100 * weights.getOrDefault("LQDT", 0.0));
    }

    private static String riskState(Score leader, Score challenger, Metrics broad, Metrics gold) {
        if (leader.score <= 0 || (broad.below200 && gold.below200)) return "RED";
        if ((leader.metrics.below200 && leader.metrics.mom63 < -0.05) || leader.metrics.maxDrawdown < -0.22) return "RED";
        if (leader.metrics.below50 || leader.metrics.annualVol > 0.35 || challenger.score < -0.03) return "ORANGE";
        if (leader.score < 0.025 || leader.metrics.mom21 < 0 || leader.metrics.annualVol > 0.25) return "YELLOW";
        return "GREEN";
    }

    private static double scoreRiskAsset(Metrics m, double officialBlend) {
        double trend = (m.above50 ? 0.010 : -0.010) + (m.above200 ? 0.015 : -0.015);
        double drawdownPenalty = Math.max(0.0, -m.maxDrawdown - 0.12) * 0.15;
        return 0.28 * m.mom21 + 0.27 * m.mom63 + 0.23 * m.mom126 + 0.12 * m.mom252
                + 0.10 * officialBlend + trend - 0.10 * m.annualVol - drawdownPenalty;
    }

    private static Metrics metrics(List<Models.PricePoint> points) {
        if (points == null || points.size() < 253) return Metrics.incomplete();
        int n = points.size();
        double last = points.get(n - 1).close;
        if (!(last > 0)) return Metrics.incomplete();
        double mom21 = returnAt(points, 21);
        double mom63 = returnAt(points, 63);
        double mom126 = returnAt(points, 126);
        double mom252 = returnAt(points, 252);
        double sma50 = meanTail(points, 50);
        double sma200 = meanTail(points, 200);
        double vol = annualVol(points, 63);
        double dd = maxDrawdown(points, 252);
        return new Metrics(true, mom21, mom63, mom126, mom252, vol, dd,
                last >= sma50, last >= sma200, last < sma50, last < sma200);
    }

    private static double returnAt(List<Models.PricePoint> p, int back) {
        int n = p.size();
        double previous = p.get(Math.max(0, n - 1 - back)).close;
        double last = p.get(n - 1).close;
        return previous > 0 ? last / previous - 1.0 : 0.0;
    }

    private static double meanTail(List<Models.PricePoint> p, int count) {
        int start = Math.max(0, p.size() - count);
        double sum = 0.0;
        for (int i = start; i < p.size(); i++) sum += p.get(i).close;
        return sum / Math.max(1, p.size() - start);
    }

    private static double annualVol(List<Models.PricePoint> p, int count) {
        int start = Math.max(1, p.size() - count);
        List<Double> returns = new ArrayList<>();
        for (int i = start; i < p.size(); i++) {
            double a = p.get(i - 1).close;
            double b = p.get(i).close;
            if (a > 0 && b > 0) returns.add(Math.log(b / a));
        }
        if (returns.size() < 2) return 0.0;
        double mean = 0.0;
        for (double r : returns) mean += r;
        mean /= returns.size();
        double variance = 0.0;
        for (double r : returns) variance += (r - mean) * (r - mean);
        variance /= returns.size();
        return Math.sqrt(variance) * Math.sqrt(252.0);
    }

    private static double maxDrawdown(List<Models.PricePoint> p, int count) {
        int start = Math.max(0, p.size() - count);
        double peak = 0.0;
        double min = 0.0;
        for (int i = start; i < p.size(); i++) {
            double value = p.get(i).close;
            peak = Math.max(peak, value);
            if (peak > 0) min = Math.min(min, value / peak - 1.0);
        }
        return min;
    }

    private static void normalize(Map<String, Double> weights) {
        double sum = 0.0;
        for (double v : weights.values()) sum += Math.max(0.0, v);
        if (!(sum > 0)) {
            weights.clear();
            weights.put("SBMX", 0.0);
            weights.put("SBGD", 0.0);
            weights.put("LQDT", 1.0);
            return;
        }
        for (String key : new ArrayList<>(weights.keySet())) {
            weights.put(key, Math.max(0.0, weights.get(key)) / sum);
        }
    }

    private static String latestDate(Models.MarketSnapshot snapshot) {
        String a = snapshot.sbmx.currentDate;
        String b = snapshot.sbgd.currentDate;
        String c = snapshot.lqdt.currentDate;
        String result = a;
        if (b != null && (result == null || b.compareTo(result) < 0)) result = b;
        if (c != null && (result == null || c.compareTo(result) < 0)) result = c;
        return result;
    }

    private static final class Score {
        final String secid;
        final String name;
        final double score;
        final Metrics metrics;
        Score(String secid, String name, double score, Metrics metrics) {
            this.secid = secid;
            this.name = name;
            this.score = score;
            this.metrics = metrics;
        }
    }

    private static final class Metrics {
        final boolean complete;
        final double mom21;
        final double mom63;
        final double mom126;
        final double mom252;
        final double annualVol;
        final double maxDrawdown;
        final boolean above50;
        final boolean above200;
        final boolean below50;
        final boolean below200;

        Metrics(boolean complete, double mom21, double mom63, double mom126, double mom252,
                double annualVol, double maxDrawdown, boolean above50, boolean above200,
                boolean below50, boolean below200) {
            this.complete = complete;
            this.mom21 = mom21;
            this.mom63 = mom63;
            this.mom126 = mom126;
            this.mom252 = mom252;
            this.annualVol = annualVol;
            this.maxDrawdown = maxDrawdown;
            this.above50 = above50;
            this.above200 = above200;
            this.below50 = below50;
            this.below200 = below200;
        }

        static Metrics incomplete() {
            return new Metrics(false, 0, 0, 0, 0, 0, 0, false, false, true, true);
        }
    }
}
