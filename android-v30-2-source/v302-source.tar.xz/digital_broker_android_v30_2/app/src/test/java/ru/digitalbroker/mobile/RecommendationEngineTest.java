package ru.digitalbroker.mobile;

import org.junit.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class RecommendationEngineTest {
    private static List<Models.PricePoint> series(double start, double daily) {
        List<Models.PricePoint> out = new ArrayList<>();
        LocalDate date = LocalDate.now().minusDays(360);
        double value = start;
        for (int i = 0; i < 300; i++) {
            value *= daily;
            out.add(new Models.PricePoint(date.plusDays(i).toString(), value));
        }
        return out;
    }

    private static Models.MarketSnapshot snapshot() {
        String d = LocalDate.now().toString();
        List<Models.PricePoint> broad = series(100, 1.0010);
        List<Models.PricePoint> gold = series(100, 1.0005);
        List<Models.PricePoint> cash = series(100, 1.00025);
        List<Models.PricePoint> cbr = series(5000, 1.00045);
        return new Models.MarketSnapshot(
                new Models.InstrumentData("SBMX", "Акции", broad.get(broad.size()-1).close, 1, d, broad, 1e9),
                new Models.InstrumentData("SBGD", "Золото", gold.get(gold.size()-1).close, 1, d, gold, 1e9),
                new Models.InstrumentData("LQDT", "Денежный рынок", cash.get(cash.size()-1).close, 1, d, cash, 1e9),
                cbr, d + "T12:00:00Z", false);
    }

    @Test public void validCapitalProducesLongOnlyAllocation() {
        Models.Recommendation r = new RecommendationEngine().recommend(20_000, snapshot());
        assertTrue(r.actionable);
        double sum = r.cashRub;
        for (Models.Allocation a : r.allocations) {
            assertTrue(a.units >= 0);
            assertTrue(a.weight >= 0 && a.weight <= 1);
            sum += a.estimatedRub;
        }
        assertTrue(sum <= 20_000.01);
    }

    @Test public void hardCapBlocksRecommendation() {
        Models.Recommendation r = new RecommendationEngine().recommend(100_001, snapshot());
        assertFalse(r.actionable);
        assertEquals("BLOCKED_CAPITAL", r.status);
    }

    @Test public void deterministicForSameInputs() {
        RecommendationEngine engine = new RecommendationEngine();
        Models.Recommendation a = engine.recommend(50_000, snapshot());
        Models.Recommendation b = engine.recommend(50_000, snapshot());
        assertEquals(a.riskState, b.riskState);
        assertEquals(a.leader, b.leader);
        assertEquals(a.cashRub, b.cashRub, 1e-9);
        assertEquals(a.allocations.size(), b.allocations.size());
    }
}
