# Test Cases / QA Pack

## TC-001: Unit tests бизнес-правил.

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-002: Integration tests DB/external clients.

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-003: Contract tests API/events/files.

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-004: E2E happy path and negative paths.

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-005: Load tests.

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-006: Stress tests.

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-007: Soak tests.

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-008: Failover tests.

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-009: DLQ/retry/replay tests.

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-010: Security tests.

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-011: Masking logs verification.

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-012: Audit trail verification.

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-013: happy path

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-014: duplicate request/event

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-015: timeout from external dependency

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-016: retry exhausted

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-017: DLQ/quarantine replay

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-018: consumer/process crash before commit

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-019: DB unavailable

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-020: schema incompatible

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-021: out-of-order event

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-022: security/auth failure

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-023: rollback/canary disable

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## TC-024: reconciliation mismatch

- Given: входные данные и зависимости подготовлены.
- When: выполняется сценарий/ошибка.
- Then: система сохраняет корректный статус, не создаёт дублей, пишет audit/metrics и позволяет recovery.

## Alternative/error scenarios from model

- **validation_error**: Где: API; Блокирует: blocking; Retry: no; После retry: reject request; Owner: Продуктовая команда

- **scoring_timeout**: Где: Сервис скоринга; Блокирует: blocking; Retry: yes; После retry: SCORING_ERROR + manual task; Owner: Команда рисков

- **crm_error**: Где: CRM; Блокирует: non_blocking; Retry: yes; После retry: DLQ/manual; Owner: Команда CRM

- **notification_error**: Где: Сервис уведомлений; Блокирует: non_blocking; Retry: yes; После retry: DLQ; Owner: Команда коммуникаций

- **dwh_export_error**: Где: DWH; Блокирует: non_blocking; Retry: yes; После retry: replay/reconciliation; Owner: Команда данных
